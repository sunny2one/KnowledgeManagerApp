# Blog Activity Manager v1.0 — Stage 1

Android Kotlin + Jetpack Compose 기반의 1단계 기본 프로젝트입니다.

## 현재 포함된 기능

- 독립 패키지명 `com.example.blogactivitymanager`
- versionCode 1 / versionName 1.0
- 홈, 키워드, 댓글, 기록, 설정, 로그 하단 탭
- 시작, 일시정지, 중지, 테스트 시작 버튼
- Foreground Service 및 상태 알림
- 알림의 일시정지·중지 버튼
- AccessibilityService 등록 및 연결 상태 확인
- Room DB 5개 테이블 기본 구성
- DataStore 작업 상태 저장
- Android 13 이상 알림 권한 요청
- 배터리 최적화 제외 설정 연결
- GitHub Actions APK 빌드

## 중요한 범위

1단계는 프로젝트 기반과 권한·서비스 연결을 검증하는 단계입니다. 네이버 앱 검색, 좋아요, 댓글 자동 입력 및 등록은 실행하지 않습니다.

## GitHub Actions 빌드

1. ZIP을 풀고 내부 파일 전체를 GitHub 저장소 최상단에 업로드합니다.
2. `.github/workflows/build-apk.yml` 경로가 정확한지 확인합니다.
3. GitHub의 Actions 탭에서 `Build Blog Activity Manager APK`를 선택합니다.
4. `Run workflow`를 누릅니다.
5. 빌드 완료 후 Artifacts에서 `BlogActivityManager_v1.0`을 내려받습니다.

## 설치 후 확인

1. APK를 설치합니다.
2. 앱을 열고 알림 권한을 허용합니다.
3. `접근성 설정 열기`를 눌러 Blog Activity Manager 접근성 서비스를 켭니다.
4. `시작`을 누르면 상단 알림이 표시되는지 확인합니다.
5. 알림의 일시정지 및 중지 버튼이 동작하는지 확인합니다.
6. 로그 탭에 버튼 선택 기록이 남는지 확인합니다.
