package com.example.blogactivitymanager.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.blogactivitymanager.data.preferences.WorkState
import com.example.blogactivitymanager.service.ActivityForegroundService
import com.example.blogactivitymanager.util.PermissionUtils
import com.example.blogactivitymanager.viewmodel.MainViewModel

private data class AppTab(val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        AppTab("홈", Icons.Default.Home),
        AppTab("키워드", Icons.Default.Key),
        AppTab("댓글", Icons.Default.ChatBubble),
        AppTab("기록", Icons.Default.Article),
        AppTab("설정", Icons.Default.Settings),
        AppTab("로그", Icons.Default.ListAlt)
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text("Blog Activity Manager") }) },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> HomeTab(viewModel, uiState.workState)
                1 -> PlaceholderTab("키워드", "2단계에서 키워드 추가·수정·삭제 기능을 연결합니다.")
                2 -> PlaceholderTab("댓글", "2단계에서 댓글 문구와 선택 방식을 연결합니다.")
                3 -> PlaceholderTab("기록", "처리 기록 테이블이 준비되어 있습니다. 실제 기록 UI는 이후 단계에서 확장합니다.")
                4 -> SettingsTab()
                else -> LogTab(uiState.logs)
            }
        }
    }
}

@Composable
private fun HomeTab(viewModel: MainViewModel, workState: WorkState) {
    val context = LocalContext.current
    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            StatusCard("현재 상태", when (workState) {
                WorkState.RUNNING -> "실행 중"
                WorkState.PAUSED -> "일시정지"
                WorkState.TESTING -> "테스트 중"
                WorkState.STOPPED -> "중지됨"
            })
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1단계 제어")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            startService(context, ActivityForegroundService.ACTION_START)
                            viewModel.record("INFO", "CONTROL", "시작 버튼 선택")
                        }) { Text("시작") }
                        OutlinedButton(onClick = {
                            startService(context, ActivityForegroundService.ACTION_PAUSE)
                            viewModel.record("WARNING", "CONTROL", "일시정지 버튼 선택")
                        }) { Text("일시정지") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            startService(context, ActivityForegroundService.ACTION_STOP)
                            viewModel.record("INFO", "CONTROL", "중지 버튼 선택")
                        }) { Text("중지") }
                        Button(onClick = {
                            startService(context, ActivityForegroundService.ACTION_TEST)
                            viewModel.record("INFO", "TEST", "테스트 시작 버튼 선택")
                        }) { Text("테스트 시작") }
                    }
                    Text("1단계에서는 네이버 화면을 조작하지 않습니다.")
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("권한 상태")
                    PermissionLine("접근성 서비스", PermissionUtils.isAccessibilityEnabled(context))
                    PermissionLine("알림 권한", PermissionUtils.isNotificationGranted(context))
                    PermissionLine("배터리 최적화 제외", PermissionUtils.isBatteryOptimizationIgnored(context))
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }) { Text("접근성 설정 열기") }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        OutlinedButton(onClick = {
                            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }) { Text("알림 권한 요청") }
                    }
                    OutlinedButton(onClick = {
                        val intent = Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }) { Text("배터리 최적화 제외 요청") }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("현재 작업 정보")
                    Text("현재 키워드: 없음")
                    Text("현재 게시글 제목: 없음")
                    Text("현재 블로그명: 없음")
                    Text("현재 단계: 기본 구조 확인")
                    Text("오늘 처리: 0 / 0")
                    Text("좋아요: 0 · 댓글: 0 · 건너뜀: 0 · 실패: 0")
                }
            }
        }
    }
}

@Composable
private fun PlaceholderTab(title: String, description: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title)
        Spacer(Modifier.height(8.dp))
        Text(description)
    }
}

@Composable
private fun SettingsTab() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("설정")
        Text("Room, DataStore, 접근성 서비스, 실행 알림 서비스가 기본 연결되어 있습니다.")
        Text("세부 작업 설정은 2단계부터 추가합니다.")
    }
}

@Composable
private fun LogTab(logs: List<com.example.blogactivitymanager.data.db.AppLogEntity>) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (logs.isEmpty()) {
            item { Text("아직 기록된 로그가 없습니다.") }
        } else {
            items(logs) { log ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${log.level} · ${log.step}")
                        Text(log.message)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusCard(label: String, value: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(label)
            Text(value)
        }
    }
}

@Composable
private fun PermissionLine(label: String, granted: Boolean) {
    Text("$label: ${if (granted) "연결됨" else "확인 필요"}")
}

private fun startService(context: Context, action: String) {
    val intent = ActivityForegroundService.intent(context, action)
    if (action == ActivityForegroundService.ACTION_STOP) {
        context.startService(intent)
    } else {
        ContextCompat.startForegroundService(context, intent)
    }
}
