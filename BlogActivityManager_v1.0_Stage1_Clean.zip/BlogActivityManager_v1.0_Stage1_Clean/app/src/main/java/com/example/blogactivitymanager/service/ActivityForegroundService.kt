package com.example.blogactivitymanager.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.blogactivitymanager.MainActivity
import com.example.blogactivitymanager.R
import com.example.blogactivitymanager.data.preferences.AppPreferences
import com.example.blogactivitymanager.data.preferences.WorkState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class ActivityForegroundService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val preferences by lazy { AppPreferences(applicationContext) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PAUSE -> updateState(WorkState.PAUSED)
            ACTION_STOP -> {
                updateState(WorkState.STOPPED)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TEST -> updateState(WorkState.TESTING)
            else -> updateState(WorkState.RUNNING)
        }

        startForeground(NOTIFICATION_ID, buildNotification(intent?.action == ACTION_TEST))
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun updateState(state: WorkState) {
        serviceScope.launch { preferences.setWorkState(state) }
        runCatching { NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification(state == WorkState.TESTING)) }
    }

    private fun buildNotification(testMode: Boolean) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(if (testMode) "Blog Activity Manager 테스트 중" else "Blog Activity Manager 실행 중")
        .setContentText("1단계 기본 서비스 상태를 유지하고 있습니다.")
        .setContentIntent(mainPendingIntent())
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .addAction(0, "일시정지", servicePendingIntent(ACTION_PAUSE, 101))
        .addAction(0, "중지", servicePendingIntent(ACTION_STOP, 102))
        .build()

    private fun mainPendingIntent(): PendingIntent = PendingIntent.getActivity(
        this,
        100,
        Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this,
            requestCode,
            Intent(this, ActivityForegroundService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "작업 상태",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Blog Activity Manager 실행 상태 알림"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        const val ACTION_START = "com.example.blogactivitymanager.action.START"
        const val ACTION_PAUSE = "com.example.blogactivitymanager.action.PAUSE"
        const val ACTION_STOP = "com.example.blogactivitymanager.action.STOP"
        const val ACTION_TEST = "com.example.blogactivitymanager.action.TEST"
        private const val CHANNEL_ID = "blog_activity_status"
        private const val NOTIFICATION_ID = 1001

        fun intent(context: Context, action: String): Intent =
            Intent(context, ActivityForegroundService::class.java).setAction(action)
    }
}
