package com.example.blogactivitymanager.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColors = lightColorScheme(
    primary = Color(0xFFF97316),
    onPrimary = Color.White,
    secondary = Color(0xFF0F766E),
    background = Color(0xFFFFFBF7),
    surface = Color.White
)

@Composable
fun BlogActivityManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AppColors, content = content)
}
