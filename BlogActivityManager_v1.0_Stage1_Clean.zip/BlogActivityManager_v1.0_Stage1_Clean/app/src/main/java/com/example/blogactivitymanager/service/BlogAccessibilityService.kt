package com.example.blogactivitymanager.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.example.blogactivitymanager.data.preferences.AppPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class BlogAccessibilityService : AccessibilityService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val preferences by lazy { AppPreferences(applicationContext) }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceScope.launch { preferences.setAccessibilityConnected(true) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Stage 1: connection validation only. No screen automation is performed here.
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        serviceScope.launch { preferences.setAccessibilityConnected(false) }
        serviceScope.cancel()
        super.onDestroy()
    }
}
