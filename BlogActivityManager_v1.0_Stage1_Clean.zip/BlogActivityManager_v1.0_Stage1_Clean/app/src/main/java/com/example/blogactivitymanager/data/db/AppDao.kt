package com.example.blogactivitymanager.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM keywords ORDER BY sortOrder ASC, id ASC")
    fun observeKeywords(): Flow<List<KeywordEntity>>

    @Query("SELECT * FROM comment_templates ORDER BY sortOrder ASC, id ASC")
    fun observeComments(): Flow<List<CommentTemplateEntity>>

    @Query("SELECT * FROM post_history ORDER BY processedAt DESC LIMIT :limit")
    fun observeRecentHistory(limit: Int = 100): Flow<List<PostHistoryEntity>>

    @Query("SELECT * FROM app_logs ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecentLogs(limit: Int = 300): Flow<List<AppLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AppLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKeyword(keyword: KeywordEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentTemplateEntity)
}
