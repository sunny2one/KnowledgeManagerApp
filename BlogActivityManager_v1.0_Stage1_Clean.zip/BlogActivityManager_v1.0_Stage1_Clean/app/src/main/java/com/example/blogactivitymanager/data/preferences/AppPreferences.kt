package com.example.blogactivitymanager.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "app_preferences")

enum class WorkState { STOPPED, RUNNING, PAUSED, TESTING }

class AppPreferences(private val context: Context) {
    private object Keys {
        val workState = stringPreferencesKey("work_state")
        val accessibilityConnected = booleanPreferencesKey("accessibility_connected")
    }

    val workState: Flow<WorkState> = context.dataStore.data.map { preferences ->
        runCatching {
            WorkState.valueOf(preferences[Keys.workState] ?: WorkState.STOPPED.name)
        }.getOrDefault(WorkState.STOPPED)
    }

    val accessibilityConnected: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[Keys.accessibilityConnected] ?: false
    }

    suspend fun setWorkState(state: WorkState) {
        context.dataStore.edit { it[Keys.workState] = state.name }
    }

    suspend fun setAccessibilityConnected(connected: Boolean) {
        context.dataStore.edit { it[Keys.accessibilityConnected] = connected }
    }
}
