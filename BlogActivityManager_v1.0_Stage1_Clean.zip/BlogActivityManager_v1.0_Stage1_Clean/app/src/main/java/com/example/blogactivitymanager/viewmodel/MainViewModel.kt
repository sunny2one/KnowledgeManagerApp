package com.example.blogactivitymanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.blogactivitymanager.BlogActivityManagerApp
import com.example.blogactivitymanager.data.db.AppLogEntity
import com.example.blogactivitymanager.data.preferences.AppPreferences
import com.example.blogactivitymanager.data.preferences.WorkState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as BlogActivityManagerApp
    private val dao = app.database.appDao()
    private val preferences = AppPreferences(application)

    val uiState = combine(
        preferences.workState,
        preferences.accessibilityConnected,
        dao.observeKeywords(),
        dao.observeComments(),
        dao.observeRecentHistory(),
        dao.observeRecentLogs()
    ) { workState, connected, keywords, comments, history, logs ->
        MainUiState(workState, connected, keywords.size, comments.size, history.size, logs)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MainUiState())

    fun record(level: String, step: String, message: String) {
        viewModelScope.launch {
            dao.insertLog(AppLogEntity(level = level, step = step, message = message))
        }
    }
}

data class MainUiState(
    val workState: WorkState = WorkState.STOPPED,
    val accessibilityConnected: Boolean = false,
    val keywordCount: Int = 0,
    val commentCount: Int = 0,
    val historyCount: Int = 0,
    val logs: List<AppLogEntity> = emptyList()
)
