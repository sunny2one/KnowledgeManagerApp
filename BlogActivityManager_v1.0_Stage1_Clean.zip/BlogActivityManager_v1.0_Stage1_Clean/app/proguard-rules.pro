# Room and accessibility related classes are referenced through Android framework metadata.
-keep class * extends android.accessibilityservice.AccessibilityService { *; }
-keep class * extends android.app.Service { *; }
-keepattributes *Annotation*
