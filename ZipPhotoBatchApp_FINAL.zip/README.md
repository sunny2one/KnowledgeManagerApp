# ZIP 사진 일괄 저장 APK

이 파일은 기존 저장소의 Android 프로젝트 이름이나 설정과 충돌하지 않도록 `ZipPhotoBatchProject` 독립 폴더에서 빌드됩니다.

## 업로드
압축을 푼 뒤 보이는 `.github`, `ZipPhotoBatchProject`, `README.md`를 저장소 최상단에 업로드하세요.

## 빌드
GitHub → Actions → `ZIP 사진 APK 빌드` → Run workflow

완료 후 Artifacts의 `ZIP-Photo-Batch-v1.0`을 내려받아 APK를 설치합니다.
