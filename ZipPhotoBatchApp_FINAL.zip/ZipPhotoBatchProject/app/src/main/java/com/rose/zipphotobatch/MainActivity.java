package com.rose.zipphotobatch;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class MainActivity extends Activity {

    private static final int REQ_PICK_ZIP = 1001;
    private static final int JPEG_QUALITY = 95;
    private static final long MAX_ENTRY_BYTES = 50L * 1024L * 1024L;

    private Button pickButton;
    private ProgressBar progressBar;
    private TextView statusText;
    private TextView detailText;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        int pad = dp(24);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("ZIP 사진 일괄 저장");
        title.setTextSize(26);
        title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        titleParams.bottomMargin = dp(12);
        root.addView(title, titleParams);

        TextView desc = new TextView(this);
        desc.setText("ZIP 파일 하나만 선택하면 사진을 자동으로 풀고 새 JPEG 파일로 저장합니다.\n원본 크기 유지 · 품질 95% · 메타데이터 제거");
        desc.setTextSize(16);
        desc.setTextColor(Color.DKGRAY);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams descParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        descParams.bottomMargin = dp(28);
        root.addView(desc, descParams);

        pickButton = new Button(this);
        pickButton.setText("ZIP 파일 선택하고 바로 처리");
        pickButton.setTextSize(17);
        pickButton.setAllCaps(false);
        pickButton.setOnClickListener(v -> openZipPicker());
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(58)
        );
        buttonParams.bottomMargin = dp(24);
        root.addView(pickButton, buttonParams);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(18)
        );
        progressParams.bottomMargin = dp(16);
        root.addView(progressBar, progressParams);

        statusText = new TextView(this);
        statusText.setText("대기 중");
        statusText.setTextSize(18);
        statusText.setTextColor(Color.BLACK);
        statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        detailText = new TextView(this);
        detailText.setText("완료된 사진은 갤러리의 Pictures/BlogReady 폴더에 나타납니다.");
        detailText.setTextSize(14);
        detailText.setTextColor(Color.GRAY);
        detailText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams detailParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        detailParams.topMargin = dp(12);
        root.addView(detailText, detailParams);

        return root;
    }

    private void openZipPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/zip",
                "application/x-zip-compressed",
                "application/octet-stream"
        });
        startActivityForResult(intent, REQ_PICK_ZIP);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_ZIP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri zipUri = data.getData();
            processZip(zipUri);
        }
    }

    private void processZip(Uri zipUri) {
        pickButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setIndeterminate(true);
        statusText.setText("ZIP 파일 확인 중...");
        detailText.setText("사진 수에 따라 잠시 걸릴 수 있습니다.");

        executor.execute(() -> {
            List<ImageItem> images;
            try {
                images = readImagesFromZip(zipUri);
            } catch (Exception e) {
                showError("ZIP 파일을 읽지 못했습니다.\n" + safeMessage(e));
                return;
            }

            if (images.isEmpty()) {
                showError("ZIP 안에서 사진을 찾지 못했습니다. JPG, JPEG, PNG, WEBP, HEIC 형식을 확인해 주세요.");
                return;
            }

            runOnUiThread(() -> {
                progressBar.setIndeterminate(false);
                progressBar.setProgress(0);
                statusText.setText("사진 0 / " + images.size());
            });

            String batchName = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date());
            int success = 0;
            int failed = 0;

            for (int i = 0; i < images.size(); i++) {
                ImageItem item = images.get(i);
                try {
                    Bitmap decoded = BitmapFactory.decodeByteArray(item.bytes, 0, item.bytes.length);
                    if (decoded == null) {
                        failed++;
                    } else {
                        Bitmap outputBitmap = flattenTransparency(decoded);
                        String fileName = String.format(Locale.KOREA, "%03d_%s.jpg", i + 1, cleanBaseName(item.name));
                        saveToGallery(outputBitmap, fileName, batchName);
                        if (outputBitmap != decoded) outputBitmap.recycle();
                        decoded.recycle();
                        success++;
                    }
                } catch (Exception e) {
                    failed++;
                }

                int done = i + 1;
                int progress = Math.round(done * 100f / images.size());
                int finalSuccess = success;
                int finalFailed = failed;
                runOnUiThread(() -> {
                    progressBar.setProgress(progress);
                    statusText.setText("사진 " + done + " / " + images.size());
                    detailText.setText("저장 성공 " + finalSuccess + "장 · 실패 " + finalFailed + "장");
                });
            }

            int finalSuccess = success;
            int finalFailed = failed;
            runOnUiThread(() -> {
                pickButton.setEnabled(true);
                progressBar.setProgress(100);
                statusText.setText("처리 완료");
                detailText.setText("Pictures/BlogReady/" + batchName + "\n성공 " + finalSuccess + "장 · 실패 " + finalFailed + "장");
                new AlertDialog.Builder(this)
                        .setTitle("완료")
                        .setMessage(finalSuccess + "장의 사진을 새 파일로 저장했습니다.\n\n갤러리에서 BlogReady 앨범을 열어 사용하세요.")
                        .setPositiveButton("확인", null)
                        .show();
            });
        });
    }

    private List<ImageItem> readImagesFromZip(Uri zipUri) throws IOException {
        List<ImageItem> result = new ArrayList<>();
        ContentResolver resolver = getContentResolver();
        try (InputStream raw = resolver.openInputStream(zipUri);
             ZipInputStream zis = new ZipInputStream(new BufferedInputStream(raw))) {

            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    zis.closeEntry();
                    continue;
                }

                String name = entry.getName();
                if (!isSupportedImage(name)) {
                    zis.closeEntry();
                    continue;
                }

                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buffer = new byte[16 * 1024];
                long total = 0;
                int read;
                while ((read = zis.read(buffer)) != -1) {
                    total += read;
                    if (total > MAX_ENTRY_BYTES) {
                        throw new IOException("사진 한 장의 용량이 50MB를 넘습니다: " + name);
                    }
                    bos.write(buffer, 0, read);
                }
                result.add(new ImageItem(name, bos.toByteArray()));
                zis.closeEntry();
            }
        }
        return result;
    }

    private void saveToGallery(Bitmap bitmap, String fileName, String batchName) throws IOException {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/BlogReady/" + batchName);
        values.put(MediaStore.Images.Media.IS_PENDING, 1);

        ContentResolver resolver = getContentResolver();
        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IOException("저장 위치를 만들지 못했습니다.");

        boolean ok = false;
        try (OutputStream out = resolver.openOutputStream(uri)) {
            if (out == null) throw new IOException("파일을 열지 못했습니다.");
            ok = bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out);
        } finally {
            if (!ok) {
                resolver.delete(uri, null, null);
            }
        }

        if (!ok) throw new IOException("JPEG 저장에 실패했습니다.");
        ContentValues done = new ContentValues();
        done.put(MediaStore.Images.Media.IS_PENDING, 0);
        resolver.update(uri, done, null, null);
    }

    private Bitmap flattenTransparency(Bitmap source) {
        if (!source.hasAlpha()) return source;
        Bitmap result = Bitmap.createBitmap(source.getWidth(), source.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(source, 0, 0, null);
        return result;
    }

    private boolean isSupportedImage(String name) {
        String lower = name.toLowerCase(Locale.US);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
                lower.endsWith(".png") || lower.endsWith(".webp") ||
                lower.endsWith(".heic") || lower.endsWith(".heif");
    }

    private String cleanBaseName(String name) {
        String onlyName = name.replace('\\', '/');
        int slash = onlyName.lastIndexOf('/');
        if (slash >= 0) onlyName = onlyName.substring(slash + 1);
        int dot = onlyName.lastIndexOf('.');
        if (dot > 0) onlyName = onlyName.substring(0, dot);
        onlyName = onlyName.replaceAll("[^a-zA-Z0-9가-힣_-]", "_");
        if (onlyName.isEmpty()) onlyName = "photo";
        return onlyName;
    }

    private String safeMessage(Exception e) {
        return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
    }

    private void showError(String message) {
        runOnUiThread(() -> {
            pickButton.setEnabled(true);
            progressBar.setVisibility(View.GONE);
            statusText.setText("처리 실패");
            detailText.setText(message);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private static class ImageItem {
        final String name;
        final byte[] bytes;

        ImageItem(String name, byte[] bytes) {
            this.name = name;
            this.bytes = bytes;
        }
    }
}
