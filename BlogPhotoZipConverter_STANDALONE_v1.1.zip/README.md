# 블로그 사진 ZIP 변환기 - 단독 앱

이 프로젝트는 기존 앱과 완전히 다른 Android 애플리케이션 ID를 사용합니다.

- 앱 이름: 블로그 사진 ZIP 변환기
- applicationId: `com.rose.blogphotozipconverter`
- APK 이름: `BlogPhotoZipConverter_Standalone_v1.1.apk`

## GitHub 업로드
이 ZIP의 내용물을 새 GitHub 저장소 최상단에 그대로 업로드하세요.
GitHub 첫 화면에 `app`, `.github`, `build.gradle`, `settings.gradle`이 바로 보여야 합니다.

## 빌드
Actions → Build Standalone Blog Photo APK → Run workflow

빌드 완료 후 Artifacts에서 `BlogPhotoZipConverter-Standalone-v1.1`을 내려받아 설치합니다.
기존 앱과 동시에 설치됩니다.
