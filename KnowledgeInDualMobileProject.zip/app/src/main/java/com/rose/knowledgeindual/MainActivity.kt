package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("step1_settings", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var leftWeb: WebView
    private lateinit var rightWeb: WebView
    private lateinit var divider: View
    private lateinit var leftUrlInput: EditText
    private lateinit var rightUrlInput: EditText
    private lateinit var toggleButton: Button

    private var leftWeight = 1f
    private var rightWeight = 1f
    private var dragStartX = 0f
    private var dragStartLeftWeight = 1f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(leftWeb)
        configureWebView(rightWeb)
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextSize(12f)
            setOnClickListener { action() }
        }

    private fun editText(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            setTextSize(13f)
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleButton = button("◀") { toggleSettings() }
        settingsPanel.addView(toggleButton, LinearLayout.LayoutParams(-1, dp(44)))

        settingsPanel.addView(TextView(this).apply {
            text = "왼쪽 페이지 주소"
            textSize = 14f
        })

        leftUrlInput = editText("https://m.kin.naver.com/")
        settingsPanel.addView(leftUrlInput, LinearLayout.LayoutParams(-1, dp(48)))

        settingsPanel.addView(TextView(this).apply {
            text = "오른쪽 GPT 주소"
            textSize = 14f
        })

        rightUrlInput = editText("https://chatgpt.com/")
        settingsPanel.addView(rightUrlInput, LinearLayout.LayoutParams(-1, dp(48)))

        settingsPanel.addView(
            button("주소 저장하고 열기") {
                leftWeb.loadUrl(normalizeUrl(leftUrlInput.text.toString()))
                rightWeb.loadUrl(normalizeUrl(rightUrlInput.text.toString()))
                saveSettings()
                Toast.makeText(this, "주소를 저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(48))
        )

        settingsPanel.addView(
            button("왼쪽 홈") {
                leftWeb.loadUrl(normalizeUrl(leftUrlInput.text.toString()))
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsPanel.addView(
            button("오른쪽 홈") {
                rightWeb.loadUrl(normalizeUrl(rightUrlInput.text.toString()))
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsPanel.addView(TextView(this).apply {
            text = "가운데 회색 바를 좌우로 움직이면 화면 비율이 저장됩니다."
            textSize = 12f
            setPadding(dp(4), dp(12), dp(4), dp(4))
        })

        val webRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        leftWeb = WebView(this)
        rightWeb = WebView(this)

        webRow.addView(leftWeb, LinearLayout.LayoutParams(0, -1, leftWeight))

        divider = View(this).apply {
            setBackgroundColor(Color.rgb(160, 160, 160))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dragStartX = event.rawX
                        dragStartLeftWeight = leftWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val width = max(webRow.width, 1)
                        val delta = (event.rawX - dragStartX) / width * 2f
                        leftWeight = min(1.8f, max(0.2f, dragStartLeftWeight + delta))
                        rightWeight = 2f - leftWeight
                        applyWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        webRow.addView(divider, LinearLayout.LayoutParams(dp(10), -1))
        webRow.addView(rightWeb, LinearLayout.LayoutParams(0, -1, rightWeight))

        root.addView(settingsPanel, LinearLayout.LayoutParams(dp(280), -1))
        root.addView(webRow, LinearLayout.LayoutParams(0, -1, 1f))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (view === leftWeb) {
                    prefs.edit().putString("left_last_url", url).apply()
                } else if (view === rightWeb) {
                    prefs.edit().putString("right_last_url", url).apply()
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun normalizeUrl(value: String): String {
        val text = value.trim()
        return when {
            text.isBlank() -> "https://chatgpt.com/"
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun loadSavedPages() {
        val left = prefs.getString(
            "left_last_url",
            prefs.getString("left_home_url", "https://m.kin.naver.com/")
        ) ?: "https://m.kin.naver.com/"

        val right = prefs.getString(
            "right_last_url",
            prefs.getString("right_home_url", "https://chatgpt.com/")
        ) ?: "https://chatgpt.com/"

        leftWeb.loadUrl(left)
        rightWeb.loadUrl(right)
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("left_home_url", normalizeUrl(leftUrlInput.text.toString()))
            .putString("right_home_url", normalizeUrl(rightUrlInput.text.toString()))
            .putFloat("left_weight", leftWeight)
            .apply()
    }

    private fun restoreSettings() {
        leftUrlInput.setText(
            prefs.getString("left_home_url", "https://m.kin.naver.com/")
        )
        rightUrlInput.setText(
            prefs.getString("right_home_url", "https://chatgpt.com/")
        )

        leftWeight = prefs.getFloat("left_weight", 1f).coerceIn(0.2f, 1.8f)
        rightWeight = 2f - leftWeight
        applyWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsPanel.post { collapseSettings() }
        }
    }

    private fun applyWeights() {
        if (!::leftWeb.isInitialized || !::rightWeb.isInitialized) return
        (leftWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = leftWeight
        (rightWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = rightWeight
        leftWeb.requestLayout()
        rightWeb.requestLayout()
    }

    private fun toggleSettings() {
        val collapsed = settingsPanel.layoutParams.width <= dp(52)
        if (collapsed) expandSettings() else collapseSettings()
    }

    private fun collapseSettings() {
        val lp = settingsPanel.layoutParams
        lp.width = dp(52)
        settingsPanel.layoutParams = lp

        for (i in 1 until settingsPanel.childCount) {
            settingsPanel.getChildAt(i).visibility = View.GONE
        }
        toggleButton.text = "▶"
        prefs.edit().putBoolean("settings_collapsed", true).apply()
    }

    private fun expandSettings() {
        val lp = settingsPanel.layoutParams
        lp.width = dp(280)
        settingsPanel.layoutParams = lp

        for (i in 1 until settingsPanel.childCount) {
            settingsPanel.getChildAt(i).visibility = View.VISIBLE
        }
        toggleButton.text = "◀"
        prefs.edit().putBoolean("settings_collapsed", false).apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            rightWeb.canGoBack() -> rightWeb.goBack()
            leftWeb.canGoBack() -> leftWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
