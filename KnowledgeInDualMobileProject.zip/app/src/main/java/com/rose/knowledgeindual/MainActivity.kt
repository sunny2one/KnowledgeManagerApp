package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Collections
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("knowledge_manager_step2_fixed", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var settingsCard: LinearLayout
    private lateinit var chatWeb: WebView
    private lateinit var naverWeb: WebView
    private lateinit var monitorWeb: WebView

    private lateinit var keywordInput: EditText
    private lateinit var keywordListText: TextView
    private lateinit var intervalInput: EditText
    private lateinit var hoursInput: EditText
    private lateinit var maxAnswersInput: EditText
    private lateinit var statusText: TextView
    private lateinit var resultList: LinearLayout
    private lateinit var naverUrlInput: EditText
    private lateinit var chatUrlInput: EditText
    private lateinit var toggleButton: Button

    private val keywords = mutableListOf<String>()
    private val detectedIds = Collections.synchronizedSet(mutableSetOf<String>())

    private var monitorJob: Job? = null
    private var keywordCursor = 0
    private var searchRecent = true

    private var leftColumnWeight = 0.78f
    private var rightColumnWeight = 1.22f
    private var topWeight = 0.95f
    private var bottomWeight = 1.05f

    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragStartLeftWeight = leftColumnWeight
    private var dragStartTopWeight = topWeight

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(chatWeb, "chat_last_url")
        configureWebView(naverWeb, "naver_last_url")
        configureMonitorWebView()
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        saveSettings()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 11f
            setOnClickListener { onClick() }
        }

    private fun input(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            textSize = 13f
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }

        settingsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10))
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleButton = button("◀ 설정창 접기") { toggleSettings() }
        settingsCard.addView(toggleButton, LinearLayout.LayoutParams(-1, dp(44)))

        settingsCard.addView(TextView(this).apply {
            text = "프로그램 설정"
            textSize = 18f
        })

        naverUrlInput = input("https://m.kin.naver.com/")
        chatUrlInput = input("https://chatgpt.com/")

        settingsCard.addView(TextView(this).apply { text = "지식인 페이지 주소" })
        settingsCard.addView(naverUrlInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsCard.addView(TextView(this).apply { text = "ChatGPT 페이지 주소" })
        settingsCard.addView(chatUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        settingsCard.addView(TextView(this).apply {
            text = "검색 키워드"
            textSize = 14f
            setPadding(0, dp(8), 0, 0)
        })

        keywordInput = input("예: 개인회생")
        settingsCard.addView(keywordInput, LinearLayout.LayoutParams(-1, dp(46)))

        val keywordRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        keywordRow.addView(button("키워드 추가") { addKeyword() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        keywordRow.addView(button("마지막 삭제") { removeLastKeyword() }, LinearLayout.LayoutParams(0, dp(42), 1f))
        settingsCard.addView(keywordRow)

        keywordListText = TextView(this).apply {
            textSize = 12f
            setPadding(dp(4))
        }
        settingsCard.addView(keywordListText)

        val conditionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        intervalInput = input("1")
        hoursInput = input("48")
        maxAnswersInput = input("5")
        conditionRow.addView(intervalInput, LinearLayout.LayoutParams(0, dp(46), 1f))
        conditionRow.addView(hoursInput, LinearLayout.LayoutParams(0, dp(46), 1f))
        conditionRow.addView(maxAnswersInput, LinearLayout.LayoutParams(0, dp(46), 1f))
        settingsCard.addView(conditionRow)

        settingsCard.addView(TextView(this).apply {
            text = "검색주기(초) / 제한시간(시간) / 최대 답변수"
            textSize = 11f
        })

        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        searchRow.addView(button("검색 시작") { startMonitor() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        searchRow.addView(button("검색 중지") { stopMonitor() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        searchRow.addView(button("목록 비우기") { clearResults() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        settingsCard.addView(searchRow)

        statusText = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setPadding(dp(4))
        }
        settingsCard.addView(statusText)

        resultList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        settingsCard.addView(resultList)

        settingsCard.addView(button("설정 저장") {
            saveSettings()
            Toast.makeText(this, "설정을 저장했습니다.", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(44)))

        settingsCard.addView(button("저장한 주소 열기") {
            naverWeb.loadUrl(normalizeUrl(naverUrlInput.text.toString(), true))
            chatWeb.loadUrl(normalizeUrl(chatUrlInput.text.toString(), false))
            saveSettings()
        }, LinearLayout.LayoutParams(-1, dp(44)))

        settingsScroll.addView(settingsCard, ScrollView.LayoutParams(-1, -2))

        chatWeb = WebView(this)
        naverWeb = WebView(this)
        monitorWeb = WebView(this).apply { visibility = View.GONE }

        leftColumn.addView(settingsScroll, LinearLayout.LayoutParams(-1, 0, topWeight))

        val horizontalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(170, 170, 170))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dragStartY = event.rawY
                        dragStartTopWeight = topWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val h = max(leftColumn.height, 1)
                        val delta = (event.rawY - dragStartY) / h * 2f
                        topWeight = min(1.8f, max(0.2f, dragStartTopWeight + delta))
                        bottomWeight = 2f - topWeight
                        applyVerticalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        leftColumn.addView(horizontalDivider, LinearLayout.LayoutParams(-1, dp(8)))
        leftColumn.addView(chatWeb, LinearLayout.LayoutParams(-1, 0, bottomWeight))

        root.addView(leftColumn, LinearLayout.LayoutParams(0, -1, leftColumnWeight))

        val verticalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(150, 150, 150))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dragStartX = event.rawX
                        dragStartLeftWeight = leftColumnWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val w = max(root.width, 1)
                        val delta = (event.rawX - dragStartX) / w * 2f
                        leftColumnWeight = min(1.8f, max(0.2f, dragStartLeftWeight + delta))
                        rightColumnWeight = 2f - leftColumnWeight
                        applyHorizontalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        root.addView(verticalDivider, LinearLayout.LayoutParams(dp(8), -1))
        root.addView(naverWeb, LinearLayout.LayoutParams(0, -1, rightColumnWeight))
        root.addView(monitorWeb, LinearLayout.LayoutParams(1, 1))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView, prefKey: String) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }
        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                prefs.edit().putString(prefKey, url).apply()
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureMonitorWebView() {
        monitorWeb.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadsImagesAutomatically = false
            userAgentString = userAgentString.replace("; wv", "")
        }
        monitorWeb.addJavascriptInterface(SearchBridge(), "SearchBridge")
        monitorWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                view.postDelayed({ parseSearchPage() }, 900)
            }
        }
    }

    private fun addKeyword() {
        val value = keywordInput.text.toString().trim()
        if (value.isBlank()) return
        if (!keywords.contains(value)) keywords.add(value)
        keywordInput.setText("")
        renderKeywords()
        saveSettings()
    }

    private fun removeLastKeyword() {
        if (keywords.isNotEmpty()) keywords.removeAt(keywords.lastIndex)
        renderKeywords()
        saveSettings()
    }

    private fun renderKeywords() {
        keywordListText.text = if (keywords.isEmpty()) {
            "등록된 키워드 없음"
        } else {
            keywords.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
        }
    }

    private fun startMonitor() {
        saveSettings()
        if (keywords.isEmpty()) {
            Toast.makeText(this, "검색 키워드를 먼저 추가해 주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        monitorJob?.cancel()
        monitorJob = lifecycleScope.launch {
            while (isActive) {
                val keyword = keywords[keywordCursor % keywords.size]
                keywordCursor = (keywordCursor + 1) % keywords.size
                val mode = if (searchRecent) "최신순" else "정확도 TOP3"
                statusText.text = "$keyword · $mode 검색 중"
                loadSearch(keyword, searchRecent)
                searchRecent = !searchRecent
                val seconds = max(1, intervalInput.text.toString().toIntOrNull() ?: 1)
                delay(seconds * 1000L)
            }
        }
    }

    private fun stopMonitor() {
        monitorJob?.cancel()
        monitorJob = null
        statusText.text = "검색 중지"
    }

    private fun loadSearch(keyword: String, recent: Boolean) {
        val encoded = URLEncoder.encode(keyword, "UTF-8")
        val sort = if (recent) "date" else "none"
        monitorWeb.tag = JSONObject()
            .put("keyword", keyword)
            .put("recent", recent)
            .toString()
        monitorWeb.loadUrl("https://search.naver.com/search.naver?where=kin&query=$encoded&sort=$sort")
    }

    private fun parseSearchPage() {
        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g, ' ').trim();
              const links = Array.from(document.querySelectorAll(
                'a[href*="kin.naver.com/qna/detail.naver"],a[href*="kin.naver.com/qna/detail"]'
              ));
              const seen = new Set();
              const rows = [];
              for (const a of links) {
                const href = a.href || '';
                if (!href || seen.has(href)) continue;
                seen.add(href);
                const box = a.closest('li,div') || a.parentElement;
                const text = clean(box ? box.innerText : a.innerText);
                const title = clean(a.innerText) || clean(a.getAttribute('title')) || text.slice(0,120);
                let answerCount = 0;
                const m = text.match(/답변\s*(\d+)|답변수\s*[:：]?\s*(\d+)/i);
                if (m) answerCount = parseInt(m[1] || m[2] || '0', 10);
                let dateText = '';
                const d = text.match(/(\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}(?:\s+\d{1,2}:\d{2})?|\d+\s*분\s*전|\d+\s*시간\s*전|\d+\s*일\s*전)/);
                if (d) dateText = d[1];
                rows.push({ id: href, href, title, answerCount, dateText });
              }
              SearchBridge.onResults(JSON.stringify(rows));
            })();
        """.trimIndent()

        monitorWeb.evaluateJavascript(js, null)
    }

    inner class SearchBridge {
        @JavascriptInterface
        fun onResults(json: String) {
            runOnUiThread { handleResults(json) }
        }
    }

    private fun handleResults(json: String) {
        val meta = runCatching {
            JSONObject(monitorWeb.tag as? String ?: "{}")
        }.getOrDefault(JSONObject())

        val keyword = meta.optString("keyword")
        val recent = meta.optBoolean("recent", true)
        val arr = runCatching { JSONArray(json) }.getOrDefault(JSONArray())

        val maxAnswers = maxAnswersInput.text.toString().toIntOrNull() ?: 5
        val maxItems = if (recent) arr.length() else min(3, arr.length())

        var added = 0
        for (i in 0 until maxItems) {
            val item = arr.optJSONObject(i) ?: continue
            val id = item.optString("id")
            if (id.isBlank() || detectedIds.contains(id)) continue
            if (item.optInt("answerCount", 0) > maxAnswers) continue

            detectedIds.add(id)
            addResultCard(
                keyword = keyword,
                mode = if (recent) "최신순" else "정확도 ${i + 1}위",
                title = item.optString("title"),
                url = item.optString("href"),
                answers = item.optInt("answerCount", 0)
            )
            added++
        }

        statusText.text = if (added > 0) {
            "$keyword · ${added}건 감지"
        } else {
            "$keyword · 새 질문 없음"
        }
        saveSettings()
    }

    private fun addResultCard(
        keyword: String,
        mode: String,
        title: String,
        url: String,
        answers: Int
    ) {
        val card = Button(this).apply {
            isAllCaps = false
            text = "[$mode] $keyword\n$title\n답변 $answers개"
            textSize = 11f
            setOnClickListener { naverWeb.loadUrl(url) }
        }
        resultList.addView(card, LinearLayout.LayoutParams(-1, -2))
    }

    private fun clearResults() {
        resultList.removeAllViews()
        detectedIds.clear()
        prefs.edit().remove("detected_ids").apply()
        statusText.text = "목록을 비웠습니다."
    }

    private fun normalizeUrl(value: String, isNaver: Boolean): String {
        val t = value.trim()
        if (t.isBlank()) return if (isNaver) "https://m.kin.naver.com/" else "https://chatgpt.com/"
        return if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
    }

    private fun loadSavedPages() {
        val naver = prefs.getString("naver_last_url", "https://m.kin.naver.com/")
            ?: "https://m.kin.naver.com/"
        val chat = prefs.getString("chat_last_url", "https://chatgpt.com/")
            ?: "https://chatgpt.com/"
        naverWeb.loadUrl(naver)
        chatWeb.loadUrl(chat)
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("keywords", JSONArray(keywords).toString())
            .putString("naver_home_url", normalizeUrl(naverUrlInput.text.toString(), true))
            .putString("chat_home_url", normalizeUrl(chatUrlInput.text.toString(), false))
            .putInt("interval", intervalInput.text.toString().toIntOrNull() ?: 1)
            .putInt("hours", hoursInput.text.toString().toIntOrNull() ?: 48)
            .putInt("max_answers", maxAnswersInput.text.toString().toIntOrNull() ?: 5)
            .putFloat("left_weight", leftColumnWeight)
            .putFloat("top_weight", topWeight)
            .putStringSet("detected_ids", detectedIds.toSet())
            .apply()
    }

    private fun restoreSettings() {
        val arr = runCatching {
            JSONArray(prefs.getString("keywords", "[]"))
        }.getOrDefault(JSONArray())
        keywords.clear()
        for (i in 0 until arr.length()) keywords.add(arr.optString(i))
        renderKeywords()

        naverUrlInput.setText(prefs.getString("naver_home_url", "https://m.kin.naver.com/"))
        chatUrlInput.setText(prefs.getString("chat_home_url", "https://chatgpt.com/"))
        intervalInput.setText(prefs.getInt("interval", 1).toString())
        hoursInput.setText(prefs.getInt("hours", 48).toString())
        maxAnswersInput.setText(prefs.getInt("max_answers", 5).toString())

        detectedIds.addAll(prefs.getStringSet("detected_ids", emptySet()) ?: emptySet())

        leftColumnWeight = prefs.getFloat("left_weight", 0.78f).coerceIn(0.2f, 1.8f)
        rightColumnWeight = 2f - leftColumnWeight
        topWeight = prefs.getFloat("top_weight", 0.95f).coerceIn(0.2f, 1.8f)
        bottomWeight = 2f - topWeight

        applyHorizontalWeights()
        applyVerticalWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsScroll.post { collapseSettings() }
        }
    }

    private fun applyHorizontalWeights() {
        (leftColumn.layoutParams as? LinearLayout.LayoutParams)?.weight = leftColumnWeight
        (naverWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = rightColumnWeight
        leftColumn.requestLayout()
        naverWeb.requestLayout()
    }

    private fun applyVerticalWeights() {
        (settingsScroll.layoutParams as? LinearLayout.LayoutParams)?.weight = topWeight
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = bottomWeight
        settingsScroll.requestLayout()
        chatWeb.requestLayout()
    }

    private fun toggleSettings() {
        if (prefs.getBoolean("settings_collapsed", false)) expandSettings() else collapseSettings()
    }

    private fun collapseSettings() {
        for (i in 1 until settingsCard.childCount) {
            settingsCard.getChildAt(i).visibility = View.GONE
        }
        toggleButton.text = "▶ 설정창 펼치기"
        topWeight = 0.22f
        bottomWeight = 1.78f
        applyVerticalWeights()
        prefs.edit()
            .putBoolean("settings_collapsed", true)
            .putFloat("top_weight", topWeight)
            .apply()
    }

    private fun expandSettings() {
        for (i in 1 until settingsCard.childCount) {
            settingsCard.getChildAt(i).visibility = View.VISIBLE
        }
        toggleButton.text = "◀ 설정창 접기"
        topWeight = 0.95f
        bottomWeight = 1.05f
        applyVerticalWeights()
        prefs.edit()
            .putBoolean("settings_collapsed", false)
            .putFloat("top_weight", topWeight)
            .apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            naverWeb.canGoBack() -> naverWeb.goBack()
            chatWeb.canGoBack() -> chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
