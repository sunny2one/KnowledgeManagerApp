package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("step1_layout_settings", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var chatWeb: WebView
    private lateinit var naverWeb: WebView
    private lateinit var verticalDivider: View
    private lateinit var horizontalDivider: View

    private lateinit var naverUrlInput: EditText
    private lateinit var chatUrlInput: EditText
    private lateinit var toggleSettingsButton: Button

    private var leftColumnWeight = 0.75f
    private var rightColumnWeight = 1.25f
    private var settingsHeightWeight = 0.72f
    private var chatHeightWeight = 1.28f

    private var startX = 0f
    private var startLeftWeight = 0.75f
    private var startY = 0f
    private var startSettingsWeight = 0.72f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(chatWeb, false)
        configureWebView(naverWeb, true)
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextSize(12f)
            setOnClickListener { action() }
        }

    private fun input(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            setTextSize(13f)
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleSettingsButton = button("◀ 설정 접기") { toggleSettingsPanel() }
        settingsPanel.addView(toggleSettingsButton, LinearLayout.LayoutParams(-1, dp(44)))

        settingsPanel.addView(TextView(this).apply {
            text = "지식인 페이지 주소"
            textSize = 14f
        })

        naverUrlInput = input("https://m.kin.naver.com/")
        settingsPanel.addView(naverUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        settingsPanel.addView(
            button("지식인 주소 저장하고 열기") {
                naverWeb.loadUrl(normalizeUrl(naverUrlInput.text.toString(), true))
                saveSettings()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsPanel.addView(TextView(this).apply {
            text = "ChatGPT 페이지 주소"
            textSize = 14f
        })

        chatUrlInput = input("https://chatgpt.com/")
        settingsPanel.addView(chatUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        settingsPanel.addView(
            button("ChatGPT 주소 저장하고 열기") {
                chatWeb.loadUrl(normalizeUrl(chatUrlInput.text.toString(), false))
                saveSettings()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsPanel.addView(
            button("전체 설정 저장") {
                saveSettings()
                Toast.makeText(this, "설정을 저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsPanel.addView(TextView(this).apply {
            text = "왼쪽/오른쪽 분할선과 위/아래 분할선을 손가락으로 움직일 수 있습니다."
            textSize = 12f
            setPadding(dp(4), dp(10), dp(4), 0)
        })

        chatWeb = WebView(this)
        naverWeb = WebView(this)

        leftColumn.addView(settingsPanel, LinearLayout.LayoutParams(-1, 0, settingsHeightWeight))

        horizontalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(155, 155, 155))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        startSettingsWeight = settingsHeightWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val height = max(leftColumn.height, 1)
                        val delta = (event.rawY - startY) / height * 2f
                        settingsHeightWeight = min(1.7f, max(0.3f, startSettingsWeight + delta))
                        chatHeightWeight = 2f - settingsHeightWeight
                        applyVerticalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        leftColumn.addView(horizontalDivider, LinearLayout.LayoutParams(-1, dp(10)))
        leftColumn.addView(chatWeb, LinearLayout.LayoutParams(-1, 0, chatHeightWeight))

        root.addView(leftColumn, LinearLayout.LayoutParams(0, -1, leftColumnWeight))

        verticalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(135, 135, 135))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startLeftWeight = leftColumnWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val width = max(root.width, 1)
                        val delta = (event.rawX - startX) / width * 2f
                        leftColumnWeight = min(1.6f, max(0.4f, startLeftWeight + delta))
                        rightColumnWeight = 2f - leftColumnWeight
                        applyHorizontalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        root.addView(verticalDivider, LinearLayout.LayoutParams(dp(10), -1))
        root.addView(naverWeb, LinearLayout.LayoutParams(0, -1, rightColumnWeight))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView, isNaver: Boolean) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_ALWAYS
        webView.setOnTouchListener { view, event ->
            view.parent.requestDisallowInterceptTouchEvent(true)
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                view.parent.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (isNaver) {
                    prefs.edit().putString("naver_last_url", url).apply()
                } else {
                    prefs.edit().putString("chat_last_url", url).apply()
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun normalizeUrl(value: String, isNaver: Boolean): String {
        val fallback = if (isNaver) "https://m.kin.naver.com/" else "https://chatgpt.com/"
        val text = value.trim()
        return when {
            text.isBlank() -> fallback
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun loadSavedPages() {
        val naverHome = prefs.getString("naver_home_url", "https://m.kin.naver.com/")
            ?: "https://m.kin.naver.com/"
        val chatHome = prefs.getString("chat_home_url", "https://chatgpt.com/")
            ?: "https://chatgpt.com/"

        val naverLast = prefs.getString("naver_last_url", naverHome) ?: naverHome
        val chatLast = prefs.getString("chat_last_url", chatHome) ?: chatHome

        naverWeb.loadUrl(naverLast)
        chatWeb.loadUrl(chatLast)
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("naver_home_url", normalizeUrl(naverUrlInput.text.toString(), true))
            .putString("chat_home_url", normalizeUrl(chatUrlInput.text.toString(), false))
            .putFloat("left_column_weight", leftColumnWeight)
            .putFloat("settings_height_weight", settingsHeightWeight)
            .apply()
    }

    private fun restoreSettings() {
        naverUrlInput.setText(
            prefs.getString("naver_home_url", "https://m.kin.naver.com/")
        )
        chatUrlInput.setText(
            prefs.getString("chat_home_url", "https://chatgpt.com/")
        )

        leftColumnWeight = prefs.getFloat("left_column_weight", 0.75f).coerceIn(0.4f, 1.6f)
        rightColumnWeight = 2f - leftColumnWeight

        settingsHeightWeight = prefs.getFloat("settings_height_weight", 0.72f).coerceIn(0.3f, 1.7f)
        chatHeightWeight = 2f - settingsHeightWeight

        applyHorizontalWeights()
        applyVerticalWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsPanel.post { collapseSettings() }
        }
    }

    private fun applyHorizontalWeights() {
        if (!::leftColumn.isInitialized || !::naverWeb.isInitialized) return
        (leftColumn.layoutParams as? LinearLayout.LayoutParams)?.weight = leftColumnWeight
        (naverWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = rightColumnWeight
        leftColumn.requestLayout()
        naverWeb.requestLayout()
    }

    private fun applyVerticalWeights() {
        if (!::settingsPanel.isInitialized || !::chatWeb.isInitialized) return
        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight = settingsHeightWeight
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = chatHeightWeight
        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun toggleSettingsPanel() {
        val collapsed = prefs.getBoolean("settings_collapsed", false)
        if (collapsed) expandSettings() else collapseSettings()
    }

    private fun collapseSettings() {
        for (i in 1 until settingsPanel.childCount) {
            settingsPanel.getChildAt(i).visibility = View.GONE
        }
        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight = 0.16f
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = 1.84f
        toggleSettingsButton.text = "▶ 설정 펼치기"
        prefs.edit().putBoolean("settings_collapsed", true).apply()
        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun expandSettings() {
        for (i in 1 until settingsPanel.childCount) {
            settingsPanel.getChildAt(i).visibility = View.VISIBLE
        }
        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight = settingsHeightWeight
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = chatHeightWeight
        toggleSettingsButton.text = "◀ 설정 접기"
        prefs.edit().putBoolean("settings_collapsed", false).apply()
        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            naverWeb.canGoBack() -> naverWeb.goBack()
            chatWeb.canGoBack() -> chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
