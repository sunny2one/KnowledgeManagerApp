package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("search_only_settings", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var settingsContent: LinearLayout
    private lateinit var chatWeb: WebView
    private lateinit var naverWeb: WebView
    private lateinit var verticalDivider: View
    private lateinit var horizontalDivider: View

    private lateinit var naverUrlInput: EditText
    private lateinit var chatUrlInput: EditText
    private lateinit var keywordInput: EditText
    private lateinit var keywordListText: TextView
    private lateinit var intervalInput: EditText
    private lateinit var hoursInput: EditText
    private lateinit var maxAnswersInput: EditText
    private lateinit var statusText: TextView
    private lateinit var resultContainer: LinearLayout
    private lateinit var toggleSettingsButton: Button

    private val keywords = mutableListOf<String>()
    private val seenIds = linkedSetOf<String>()

    private var leftColumnWeight = 0.75f
    private var rightColumnWeight = 1.25f
    private var settingsHeightWeight = 0.72f
    private var chatHeightWeight = 1.28f

    private var startX = 0f
    private var startLeftWeight = 0.75f
    private var startY = 0f
    private var startSettingsWeight = 0.72f

    private val handler = Handler(Looper.getMainLooper())
    private var monitoring = false
    private var keywordIndex = 0
    private var recentMode = true
    private var waitingForSearchPage = false
    private var activeKeyword = ""
    private var activeRecent = true
    private var userLastNaverUrl = "https://m.kin.naver.com/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(chatWeb, false)
        configureWebView(naverWeb, true)
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        monitoring = false
        handler.removeCallbacksAndMessages(null)
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun input(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            textSize = 13f
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleSettingsButton = button("◀ 설정 접기") { toggleSettingsPanel() }
        settingsPanel.addView(
            toggleSettingsButton,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }

        settingsContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(16))
        }

        settingsScroll.addView(
            settingsContent,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        settingsPanel.addView(
            settingsScroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        addPageSettings()
        addSearchSettings()
        addResultArea()

        chatWeb = WebView(this)
        naverWeb = WebView(this)

        leftColumn.addView(
            settingsPanel,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                settingsHeightWeight
            )
        )

        horizontalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(155, 155, 155))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        startSettingsWeight = settingsHeightWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val height = max(leftColumn.height, 1)
                        val delta = (event.rawY - startY) / height * 2f
                        settingsHeightWeight =
                            min(1.7f, max(0.3f, startSettingsWeight + delta))
                        chatHeightWeight = 2f - settingsHeightWeight
                        applyVerticalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        leftColumn.addView(
            horizontalDivider,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(10)
            )
        )

        leftColumn.addView(
            chatWeb,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                chatHeightWeight
            )
        )

        root.addView(
            leftColumn,
            LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT,
                leftColumnWeight
            )
        )

        verticalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(135, 135, 135))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startLeftWeight = leftColumnWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val width = max(root.width, 1)
                        val delta = (event.rawX - startX) / width * 2f
                        leftColumnWeight =
                            min(1.6f, max(0.4f, startLeftWeight + delta))
                        rightColumnWeight = 2f - leftColumnWeight
                        applyHorizontalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        root.addView(
            verticalDivider,
            LinearLayout.LayoutParams(
                dp(10),
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        )

        root.addView(
            naverWeb,
            LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT,
                rightColumnWeight
            )
        )


        setContentView(root)
    }

    private fun addPageSettings() {
        settingsContent.addView(TextView(this).apply {
            text = "페이지 설정"
            textSize = 15f
            setTextColor(Color.rgb(20, 90, 190))
        })

        settingsContent.addView(TextView(this).apply {
            text = "지식인 페이지 주소"
            textSize = 13f
        })

        naverUrlInput = input("https://m.kin.naver.com/")
        settingsContent.addView(
            naverUrlInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(46)
            )
        )

        settingsContent.addView(
            button("지식인 주소 저장하고 열기") {
                naverWeb.loadUrl(normalizeUrl(naverUrlInput.text.toString(), true))
                saveSettings()
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        settingsContent.addView(TextView(this).apply {
            text = "ChatGPT 페이지 주소"
            textSize = 13f
        })

        chatUrlInput = input("https://chatgpt.com/")
        settingsContent.addView(
            chatUrlInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(46)
            )
        )

        settingsContent.addView(
            button("ChatGPT 주소 저장하고 열기") {
                chatWeb.loadUrl(normalizeUrl(chatUrlInput.text.toString(), false))
                saveSettings()
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )
    }

    private fun addSearchSettings() {
        settingsContent.addView(TextView(this).apply {
            text = "검색 기능"
            textSize = 15f
            setTextColor(Color.rgb(20, 90, 190))
            setPadding(0, dp(12), 0, dp(4))
        })

        keywordInput = input("검색 키워드 입력")
        settingsContent.addView(
            keywordInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(46)
            )
        )

        val keywordButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        keywordButtons.addView(
            button("키워드 추가") { addKeyword() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )

        keywordButtons.addView(
            button("마지막 삭제") { removeLastKeyword() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )

        settingsContent.addView(keywordButtons)

        keywordListText = TextView(this).apply {
            textSize = 12f
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setBackgroundColor(Color.WHITE)
        }

        settingsContent.addView(
            keywordListText,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(92)
            )
        )

        intervalInput = input("검색 주기(초)")
        hoursInput = input("48시간 이내")
        maxAnswersInput = input("답변 5개 이하")

        settingsContent.addView(
            intervalInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        settingsContent.addView(
            hoursInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        settingsContent.addView(
            maxAnswersInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        val runButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        runButtons.addView(
            button("검색 시작") { startMonitoring() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )

        runButtons.addView(
            button("검색 중지") { stopMonitoring() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )

        settingsContent.addView(runButtons)

        settingsContent.addView(
            button("보던 지식인 페이지로 돌아가기") {
                stopMonitoring(false)
                naverWeb.loadUrl(userLastNaverUrl)
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        settingsContent.addView(
            button("전체 설정 저장") {
                saveSettings()
                Toast.makeText(this, "설정을 저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44)
            )
        )

        statusText = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        settingsContent.addView(statusText)
    }

    private fun addResultArea() {
        settingsContent.addView(TextView(this).apply {
            text = "감지된 질문"
            textSize = 15f
            setTextColor(Color.rgb(20, 90, 190))
            setPadding(0, dp(10), 0, dp(4))
        })

        resultContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsContent.addView(
            resultContainer,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun configureWebView(webView: WebView, isNaver: Boolean) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_ALWAYS

        webView.setOnTouchListener { view, event ->
            view.parent?.requestDisallowInterceptTouchEvent(true)
            if (event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL) {
                view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        if (isNaver) {
            webView.addJavascriptInterface(SearchBridge(), "SearchBridge")
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (isNaver) {
                    if (monitoring && waitingForSearchPage && isSearchUrl(url)) {
                        view.postDelayed({ parseSearchPage() }, 1200)
                    } else if (!monitoring && !isSearchUrl(url)) {
                        userLastNaverUrl = url
                        prefs.edit().putString("naver_last_url", url).apply()
                    }
                } else {
                    prefs.edit().putString("chat_last_url", url).apply()
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun isSearchUrl(url: String): Boolean =
        url.contains("search.naver.com/search.naver")

    private fun normalizeUrl(value: String, isNaver: Boolean): String {
        val fallback =
            if (isNaver) "https://m.kin.naver.com/" else "https://chatgpt.com/"
        val text = value.trim()

        return when {
            text.isBlank() -> fallback
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun loadSavedPages() {
        val naverHome =
            prefs.getString("naver_home_url", "https://m.kin.naver.com/")
                ?: "https://m.kin.naver.com/"

        val chatHome =
            prefs.getString("chat_home_url", "https://chatgpt.com/")
                ?: "https://chatgpt.com/"

        userLastNaverUrl =
            prefs.getString("naver_last_url", naverHome) ?: naverHome

        naverWeb.loadUrl(userLastNaverUrl)

        chatWeb.loadUrl(
            prefs.getString("chat_last_url", chatHome) ?: chatHome
        )
    }

    private fun addKeyword() {
        val keyword = keywordInput.text.toString().trim()
        if (keyword.isBlank()) return

        if (!keywords.contains(keyword)) {
            keywords.add(keyword)
        }

        keywordInput.setText("")
        renderKeywords()
        saveSettings()
    }

    private fun removeLastKeyword() {
        if (keywords.isNotEmpty()) {
            keywords.removeAt(keywords.lastIndex)
        }

        renderKeywords()
        saveSettings()
    }

    private fun renderKeywords() {
        keywordListText.text =
            if (keywords.isEmpty()) {
                "등록된 키워드 없음"
            } else {
                keywords.mapIndexed { index, keyword ->
                    "${index + 1}. $keyword"
                }.joinToString("\n")
            }
    }

    private fun startMonitoring() {
        saveSettings()

        if (keywords.isEmpty()) {
            Toast.makeText(this, "검색 키워드를 먼저 추가해 주세요.", Toast.LENGTH_SHORT).show()
            return
        }

        if (!isSearchUrl(naverWeb.url.orEmpty())) {
            userLastNaverUrl = naverWeb.url ?: userLastNaverUrl
        }

        monitoring = true
        waitingForSearchPage = false
        keywordIndex = 0
        recentMode = true
        handler.removeCallbacksAndMessages(null)
        statusText.text = "검색 시작"
        runNextSearch()
    }

    private fun stopMonitoring(returnToLastPage: Boolean = true) {
        monitoring = false
        waitingForSearchPage = false
        handler.removeCallbacksAndMessages(null)
        statusText.text = "검색 중지"
        if (returnToLastPage) naverWeb.loadUrl(userLastNaverUrl)
    }

    private fun runNextSearch() {
        if (!monitoring || keywords.isEmpty() || waitingForSearchPage) return

        activeKeyword = keywords[keywordIndex % keywords.size]
        keywordIndex = (keywordIndex + 1) % keywords.size
        activeRecent = recentMode
        recentMode = !recentMode

        val mode = if (activeRecent) "최신순" else "정확도 TOP3"
        statusText.text = "$activeKeyword · $mode 검색 중"
        waitingForSearchPage = true
        loadSearch(activeKeyword, activeRecent)

        handler.postDelayed({
            if (monitoring && waitingForSearchPage) {
                waitingForSearchPage = false
                statusText.text = "$activeKeyword · 검색 응답 지연"
                scheduleNextSearch()
            }
        }, 15000L)
    }

    private fun scheduleNextSearch() {
        if (!monitoring) return
        val seconds = max(1, intervalInput.text.toString().toIntOrNull() ?: 1)
        handler.postDelayed({ runNextSearch() }, seconds * 1000L)
    }

    private fun loadSearch(keyword: String, recent: Boolean) {
        val encoded = URLEncoder.encode(keyword, "UTF-8")
        val sort = if (recent) "date" else "none"
        val url = "https://m.search.naver.com/search.naver?where=m_kin&sm=mtb_jum&query=$encoded&sort=$sort"
        naverWeb.stopLoading()
        naverWeb.loadUrl(url)
    }

    private fun parseSearchPage() {
        if (!monitoring || !waitingForSearchPage) return

        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g, ' ').trim();
              const links = Array.from(document.querySelectorAll('a[href]')).filter(a => {
                const h = a.href || '';
                return h.includes('kin.naver.com') &&
                  (h.includes('/qna/detail.naver') || h.includes('/mobile/qna/detail.naver'));
              });
              const used = new Set();
              const rows = [];

              for (const a of links) {
                const href = a.href || '';
                if (!href || used.has(href)) continue;
                used.add(href);

                let box = a;
                for (let i = 0; i < 8 && box && box.parentElement; i++) {
                  const t = clean(box.innerText);
                  if (t.length >= 25 && t.length <= 2200) break;
                  box = box.parentElement;
                }

                const text = clean(box ? box.innerText : a.innerText);
                let title = clean(a.innerText) || clean(a.getAttribute('title'));
                if (!title || title.length < 2) {
                  const node = box && box.querySelector('[class*="title"], strong, h2, h3, .tit');
                  title = clean(node ? node.innerText : '');
                }
                if (!title) title = text.slice(0, 120);

                let answerCount = 0;
                const am = text.match(/(?:답변|답변수)\s*[:：]?\s*(\d+)/i);
                if (am) answerCount = parseInt(am[1] || '0', 10);

                let dateText = '';
                const dm = text.match(/(\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}\.?(?:\s+\d{1,2}:\d{2})?|\d+\s*분\s*전|\d+\s*시간\s*전|\d+\s*일\s*전|어제)/);
                if (dm) dateText = dm[1];

                let id = href;
                try {
                  const u = new URL(href);
                  const docId = u.searchParams.get('docId') || u.searchParams.get('docid') || '';
                  const dirId = u.searchParams.get('dirId') || u.searchParams.get('dirid') || '';
                  if (docId) id = docId + '_' + dirId;
                } catch (_) {}

                rows.push({id, href, title, answerCount, dateText});
              }

              SearchBridge.onSearchResults(JSON.stringify(rows));
            })();
        """.trimIndent()

        naverWeb.evaluateJavascript(js, null)
    }

    inner class SearchBridge {
        @JavascriptInterface
        fun onSearchResults(json: String) {
            runOnUiThread {
                processSearchResults(json)
            }
        }
    }

    private fun processSearchResults(json: String) {
        if (!monitoring || !waitingForSearchPage) return

        val keyword = activeKeyword
        val recent = activeRecent
        val rows = try {
            JSONArray(json)
        } catch (_: Exception) {
            JSONArray()
        }
        val rawCount = rows.length()

        val maxAnswers =
            maxAnswersInput.text.toString().toIntOrNull() ?: 5

        val hoursLimit =
            hoursInput.text.toString().toIntOrNull() ?: 48

        val limit =
            if (recent) rows.length() else min(3, rows.length())

        var added = 0

        for (index in 0 until limit) {
            val item = rows.optJSONObject(index) ?: continue
            val id = item.optString("id")

            if (id.isBlank() || seenIds.contains(id)) continue

            val answerCount = item.optInt("answerCount", 0)
            if (answerCount > maxAnswers) continue

            val dateText = item.optString("dateText")
            if (!isWithinHours(dateText, hoursLimit)) continue

            addQuestionCard(
                keyword = keyword,
                mode = if (recent) "최신순" else "정확도 ${index + 1}위",
                title = item.optString("title"),
                url = item.optString("href"),
                answerCount = answerCount,
                dateText = dateText
            )

            seenIds.add(id)
            added++
        }

        statusText.text =
            if (added > 0) {
                "$keyword · ${added}건 감지"
            } else if (rawCount == 0) {
                "$keyword · 검색 결과 링크를 읽지 못함"
            } else {
                "$keyword · 조건에 맞는 새 질문 없음"
            }

        waitingForSearchPage = false
        saveSettings()
        scheduleNextSearch()
    }

    private fun addQuestionCard(
        keyword: String,
        mode: String,
        title: String,
        url: String,
        answerCount: Int,
        dateText: String
    ) {
        val card = Button(this).apply {
            isAllCaps = false
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            textSize = 11f
            setPadding(dp(8), dp(6), dp(8), dp(6))
            text = buildString {
                append("[$mode] $keyword\n")
                append(title.ifBlank { "제목 없음" })
                append("\n답변 $answerCount")
                if (dateText.isNotBlank()) {
                    append(" · $dateText")
                }
            }
            setOnClickListener {
                monitoring = false
                waitingForSearchPage = false
                handler.removeCallbacksAndMessages(null)
                userLastNaverUrl = url
                naverWeb.loadUrl(url)
            }
        }

        resultContainer.addView(
            card,
            0,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(88)
            )
        )

        while (resultContainer.childCount > 30) {
            resultContainer.removeViewAt(
                resultContainer.childCount - 1
            )
        }
    }

    private fun isWithinHours(dateText: String, hoursLimit: Int): Boolean {
        if (dateText.isBlank()) return true

        val now = LocalDateTime.now(ZoneId.systemDefault())
        val normalized = dateText.replace(" ", "")

        if (normalized == "어제") {
            return hoursLimit >= 24
        }

        Regex("""(\d+)분전""").find(normalized)?.let {
            return it.groupValues[1].toLong() <= hoursLimit * 60L
        }

        Regex("""(\d+)시간전""").find(normalized)?.let {
            return it.groupValues[1].toLong() <= hoursLimit
        }

        Regex("""(\d+)일전""").find(normalized)?.let {
            return it.groupValues[1].toLong() * 24L <= hoursLimit
        }

        val dateTimeFormats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm")
        )

        for (format in dateTimeFormats) {
            try {
                val parsed = LocalDateTime.parse(dateText.trim(), format)
                val hours = Duration.between(parsed, now).toHours()
                return hours in 0..hoursLimit.toLong()
            } catch (_: Exception) {
            }
        }

        val dateFormats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd")
        )

        for (format in dateFormats) {
            try {
                val parsed =
                    LocalDate.parse(dateText.trim(), format).atStartOfDay()
                val hours = Duration.between(parsed, now).toHours()
                return hours in 0..hoursLimit.toLong()
            } catch (_: Exception) {
            }
        }

        return true
    }

    private fun saveSettings() {
        prefs.edit()
            .putString(
                "naver_home_url",
                normalizeUrl(naverUrlInput.text.toString(), true)
            )
            .putString(
                "chat_home_url",
                normalizeUrl(chatUrlInput.text.toString(), false)
            )
            .putString("naver_last_url", userLastNaverUrl)
            .putFloat("left_column_weight", leftColumnWeight)
            .putFloat("settings_height_weight", settingsHeightWeight)
            .putString("keywords", JSONArray(keywords).toString())
            .putInt(
                "interval_seconds",
                intervalInput.text.toString().toIntOrNull() ?: 1
            )
            .putInt(
                "hours_limit",
                hoursInput.text.toString().toIntOrNull() ?: 48
            )
            .putInt(
                "max_answers",
                maxAnswersInput.text.toString().toIntOrNull() ?: 5
            )
            .putStringSet("seen_ids", seenIds.toSet())
            .apply()
    }

    private fun restoreSettings() {
        naverUrlInput.setText(
            prefs.getString(
                "naver_home_url",
                "https://m.kin.naver.com/"
            )
        )

        chatUrlInput.setText(
            prefs.getString(
                "chat_home_url",
                "https://chatgpt.com/"
            )
        )

        intervalInput.setText(
            prefs.getInt("interval_seconds", 1).toString()
        )

        hoursInput.setText(
            prefs.getInt("hours_limit", 48).toString()
        )

        maxAnswersInput.setText(
            prefs.getInt("max_answers", 5).toString()
        )

        keywords.clear()

        val savedKeywords = try {
            JSONArray(prefs.getString("keywords", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }

        for (index in 0 until savedKeywords.length()) {
            val value = savedKeywords.optString(index)
            if (value.isNotBlank()) {
                keywords.add(value)
            }
        }

        renderKeywords()

        seenIds.addAll(
            prefs.getStringSet("seen_ids", emptySet()) ?: emptySet()
        )

        leftColumnWeight =
            prefs.getFloat("left_column_weight", 0.75f)
                .coerceIn(0.4f, 1.6f)

        rightColumnWeight = 2f - leftColumnWeight

        settingsHeightWeight =
            prefs.getFloat("settings_height_weight", 0.72f)
                .coerceIn(0.3f, 1.7f)

        chatHeightWeight = 2f - settingsHeightWeight

        applyHorizontalWeights()
        applyVerticalWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsPanel.post {
                collapseSettings()
            }
        }
    }

    private fun applyHorizontalWeights() {
        if (!::leftColumn.isInitialized || !::naverWeb.isInitialized) return

        (leftColumn.layoutParams as? LinearLayout.LayoutParams)?.weight =
            leftColumnWeight

        (naverWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            rightColumnWeight

        leftColumn.requestLayout()
        naverWeb.requestLayout()
    }

    private fun applyVerticalWeights() {
        if (!::settingsPanel.isInitialized || !::chatWeb.isInitialized) return

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            settingsHeightWeight

        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            chatHeightWeight

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun toggleSettingsPanel() {
        val collapsed =
            prefs.getBoolean("settings_collapsed", false)

        if (collapsed) {
            expandSettings()
        } else {
            collapseSettings()
        }
    }

    private fun collapseSettings() {
        settingsScroll.visibility = View.GONE

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            0.16f

        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            1.84f

        toggleSettingsButton.text = "▶ 설정 펼치기"

        prefs.edit()
            .putBoolean("settings_collapsed", true)
            .apply()

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun expandSettings() {
        settingsScroll.visibility = View.VISIBLE

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            settingsHeightWeight

        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            chatHeightWeight

        toggleSettingsButton.text = "◀ 설정 접기"

        prefs.edit()
            .putBoolean("settings_collapsed", false)
            .apply()

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            naverWeb.canGoBack() -> naverWeb.goBack()
            chatWeb.canGoBack() -> chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
