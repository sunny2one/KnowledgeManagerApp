package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Duration
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Collections
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("knowledge_in_dual", MODE_PRIVATE) }
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private lateinit var root: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var contentRow: LinearLayout
    private lateinit var leftWeb: WebView
    private lateinit var rightWeb: WebView
    private lateinit var monitorWeb: WebView
    private lateinit var divider: View

    private lateinit var keywordInput: EditText
    private lateinit var keywordListText: TextView
    private lateinit var botTokenInput: EditText
    private lateinit var chatIdInput: EditText
    private lateinit var gptUrlInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var hoursInput: EditText
    private lateinit var maxAnswersInput: EditText
    private lateinit var statusText: TextView
    private lateinit var toggleSettingsButton: Button

    private val keywords = mutableListOf<String>()
    private val sentIds = Collections.synchronizedSet(mutableSetOf<String>())
    private var monitorJob: Job? = null
    private var keywordCursor = 0
    private var searchModeRecent = true
    private var questionText = ""
    private var answerText = ""
    private var leftWeight = 1.0f
    private var rightWeight = 1.0f
    private var dragStartX = 0f
    private var dragStartLeftWeight = 1f

    companion object {
        private const val DEFAULT_NAVER = "https://m.kin.naver.com/"
        private const val DEFAULT_GPT = "https://chatgpt.com/"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(WebView(this), true)

        buildUi()
        restoreSettings()
        configureWebViews()
        loadInitialPages()
    }

    override fun onPause() {
        super.onPause()
        saveSettings()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun textInput(hint: String, singleLine: Boolean = true): EditText =
        EditText(this).apply {
            this.hint = hint
            this.isSingleLine = singleLine
            setTextSize(14f)
            setPadding(dp(10))
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextSize(12f)
            setOnClickListener { action() }
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8))
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleSettingsButton = button("◀") { toggleSettingsPanel() }
        settingsPanel.addView(toggleSettingsButton, LinearLayout.LayoutParams(-1, dp(42)))

        settingsPanel.addView(TextView(this).apply {
            text = "검색 키워드"
            textSize = 16f
        })

        keywordInput = textInput("예: 개인회생")
        settingsPanel.addView(keywordInput, LinearLayout.LayoutParams(-1, dp(48)))

        val keywordButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        keywordButtons.addView(button("추가") { addKeyword() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        keywordButtons.addView(button("선택 삭제") { removeLastKeyword() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        settingsPanel.addView(keywordButtons)

        keywordListText = TextView(this).apply {
            text = "등록된 키워드 없음"
            textSize = 13f
            setPadding(dp(6))
        }
        settingsPanel.addView(keywordListText, LinearLayout.LayoutParams(-1, dp(100)))

        intervalInput = textInput("검색 주기(초)")
        hoursInput = textInput("질문 제한 시간")
        maxAnswersInput = textInput("최대 답변 수")
        botTokenInput = textInput("텔레그램 Bot Token")
        chatIdInput = textInput("텔레그램 Chat ID")
        gptUrlInput = textInput("나만의 GPT 주소")

        settingsPanel.addView(intervalInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsPanel.addView(hoursInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsPanel.addView(maxAnswersInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsPanel.addView(botTokenInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsPanel.addView(chatIdInput, LinearLayout.LayoutParams(-1, dp(46)))
        settingsPanel.addView(gptUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        val controlRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controlRow.addView(button("저장") {
            saveSettings()
            rightWeb.loadUrl(normalizeUrl(gptUrlInput.text.toString()))
            toast("설정을 저장했습니다.")
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        controlRow.addView(button("시작") { startMonitor() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        controlRow.addView(button("중지") { stopMonitor() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        settingsPanel.addView(controlRow)

        statusText = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setPadding(dp(6))
        }
        settingsPanel.addView(statusText, LinearLayout.LayoutParams(-1, 0, 1f))

        val mainColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val toolRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        toolRow.addView(button("질문 다시 가져오기") { extractQuestion() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        toolRow.addView(button("GPT로 보내기") { sendQuestionToGpt() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        toolRow.addView(button("답변 다시 가져오기") { extractAnswer() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        toolRow.addView(button("네이버에 붙여넣기") { pasteAnswerToNaver() }, LinearLayout.LayoutParams(0, dp(52), 1f))
        mainColumn.addView(toolRow)

        contentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        leftWeb = WebView(this)
        rightWeb = WebView(this)
        monitorWeb = WebView(this).apply { visibility = View.GONE }

        contentRow.addView(leftWeb, LinearLayout.LayoutParams(0, -1, leftWeight))

        divider = View(this).apply {
            setBackgroundColor(Color.rgb(180, 180, 180))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        dragStartX = event.rawX
                        dragStartLeftWeight = leftWeight
                        true
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        val width = max(contentRow.width, 1)
                        val delta = (event.rawX - dragStartX) / width * 2f
                        leftWeight = min(1.8f, max(0.2f, dragStartLeftWeight + delta))
                        rightWeight = 2f - leftWeight
                        applyWeights()
                        true
                    }
                    android.view.MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }
        contentRow.addView(divider, LinearLayout.LayoutParams(dp(8), -1))
        contentRow.addView(rightWeb, LinearLayout.LayoutParams(0, -1, rightWeight))
        mainColumn.addView(contentRow, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(settingsPanel, LinearLayout.LayoutParams(dp(280), -1))
        root.addView(mainColumn, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(monitorWeb, LinearLayout.LayoutParams(1, 1))
        setContentView(root)
    }

    private fun applyWeights() {
        (leftWeb.layoutParams as LinearLayout.LayoutParams).weight = leftWeight
        (rightWeb.layoutParams as LinearLayout.LayoutParams).weight = rightWeight
        leftWeb.requestLayout()
        rightWeb.requestLayout()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(webView: WebView, bridgeName: String? = null, bridge: Any? = null) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (view === leftWeb) prefs.edit().putString("left_url", url).apply()
                if (view === rightWeb) prefs.edit().putString("right_url", url).apply()
                if (view === monitorWeb) {
                    view.postDelayed({ parseSearchPage() }, 700)
                }
            }
        }
        if (bridgeName != null && bridge != null) {
            webView.addJavascriptInterface(bridge, bridgeName)
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun configureWebViews() {
        setupWebView(leftWeb, "NaverBridge", NaverBridge())
        setupWebView(rightWeb, "GptBridge", GptBridge())
        setupWebView(monitorWeb, "SearchBridge", SearchBridge())
    }

    private fun loadInitialPages() {
        leftWeb.loadUrl(prefs.getString("left_url", DEFAULT_NAVER) ?: DEFAULT_NAVER)
        rightWeb.loadUrl(prefs.getString("right_url", normalizeUrl(gptUrlInput.text.toString())) ?: DEFAULT_GPT)
    }

    private fun normalizeUrl(value: String): String {
        val trimmed = value.trim()
        return when {
            trimmed.isBlank() -> DEFAULT_GPT
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            else -> "https://$trimmed"
        }
    }

    private fun addKeyword() {
        val keyword = keywordInput.text.toString().trim()
        if (keyword.isBlank()) return
        if (!keywords.contains(keyword)) keywords.add(keyword)
        keywordInput.setText("")
        renderKeywords()
        saveSettings()
    }

    private fun removeLastKeyword() {
        if (keywords.isNotEmpty()) keywords.removeAt(keywords.lastIndex)
        renderKeywords()
        saveSettings()
    }

    private fun renderKeywords() {
        keywordListText.text = if (keywords.isEmpty()) {
            "등록된 키워드 없음"
        } else {
            keywords.mapIndexed { i, value -> "${i + 1}. $value" }.joinToString("\n")
        }
    }

    private fun toggleSettingsPanel() {
        val lp = settingsPanel.layoutParams
        val collapsed = lp.width <= dp(52)
        lp.width = if (collapsed) dp(280) else dp(52)
        settingsPanel.layoutParams = lp

        for (i in 1 until settingsPanel.childCount) {
            settingsPanel.getChildAt(i).visibility = if (collapsed) View.VISIBLE else View.GONE
        }
        toggleSettingsButton.text = if (collapsed) "◀" else "▶"
        prefs.edit().putBoolean("settings_collapsed", !collapsed).apply()
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("keywords", JSONArray(keywords).toString())
            .putString("bot_token", botTokenInput.text.toString().trim())
            .putString("chat_id", chatIdInput.text.toString().trim())
            .putString("gpt_url", gptUrlInput.text.toString().trim())
            .putInt("interval_seconds", intervalInput.text.toString().toIntOrNull() ?: 1)
            .putInt("hours_limit", hoursInput.text.toString().toIntOrNull() ?: 48)
            .putInt("max_answers", maxAnswersInput.text.toString().toIntOrNull() ?: 5)
            .putFloat("left_weight", leftWeight)
            .putStringSet("sent_ids", sentIds.toSet())
            .apply()
    }

    private fun restoreSettings() {
        keywords.clear()
        val array = runCatching {
            JSONArray(prefs.getString("keywords", "[]"))
        }.getOrDefault(JSONArray())
        for (i in 0 until array.length()) keywords.add(array.optString(i))

        botTokenInput.setText(prefs.getString("bot_token", ""))
        chatIdInput.setText(prefs.getString("chat_id", ""))
        gptUrlInput.setText(prefs.getString("gpt_url", DEFAULT_GPT))
        intervalInput.setText(prefs.getInt("interval_seconds", 1).toString())
        hoursInput.setText(prefs.getInt("hours_limit", 48).toString())
        maxAnswersInput.setText(prefs.getInt("max_answers", 5).toString())

        leftWeight = prefs.getFloat("left_weight", 1f).coerceIn(0.2f, 1.8f)
        rightWeight = 2f - leftWeight
        sentIds.addAll(prefs.getStringSet("sent_ids", emptySet()) ?: emptySet())
        renderKeywords()
        applyWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsPanel.post { toggleSettingsPanel() }
        }
    }

    private fun startMonitor() {
        saveSettings()
        if (keywords.isEmpty()) {
            toast("검색 키워드를 먼저 추가해 주세요.")
            return
        }
        if (botTokenInput.text.isBlank() || chatIdInput.text.isBlank()) {
            toast("텔레그램 Bot Token과 Chat ID를 입력해 주세요.")
            return
        }

        monitorJob?.cancel()
        monitorJob = lifecycleScope.launch {
            status("검색 시작")
            var consecutiveErrors = 0

            while (isActive) {
                try {
                    val keyword = keywords[keywordCursor % keywords.size]
                    keywordCursor = (keywordCursor + 1) % keywords.size

                    val mode = if (searchModeRecent) "최신순" else "정확도 TOP3"
                    status("$keyword · $mode 검색 중")
                    loadSearch(keyword, searchModeRecent)
                    searchModeRecent = !searchModeRecent
                    consecutiveErrors = 0

                    val interval = max(1, intervalInput.text.toString().toIntOrNull() ?: 1)
                    delay(interval * 1000L)
                } catch (e: Exception) {
                    consecutiveErrors++
                    status("검색 오류: ${e.message ?: "알 수 없는 오류"}")
                    val wait = min(60, 2 shl min(consecutiveErrors, 5))
                    delay(wait * 1000L)
                }
            }
        }
    }

    private fun stopMonitor() {
        monitorJob?.cancel()
        monitorJob = null
        status("검색 중지")
    }

    private fun loadSearch(keyword: String, recent: Boolean) {
        val encoded = URLEncoder.encode(keyword, "UTF-8")
        // 네이버 통합검색의 지식iN 영역. sort=date는 최신순, sort=none은 정확도순으로 사용.
        val sort = if (recent) "date" else "none"
        val url = "https://search.naver.com/search.naver?where=kin&query=$encoded&sort=$sort"
        monitorWeb.loadUrl(url)
        monitorWeb.tag = JSONObject()
            .put("keyword", keyword)
            .put("recent", recent)
            .toString()
    }

    private fun parseSearchPage() {
        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g, ' ').trim();
              const anchors = Array.from(document.querySelectorAll('a[href*="kin.naver.com/qna/detail.naver"], a[href*="kin.naver.com/qna/detail"]'));
              const seen = new Set();
              const rows = [];

              for (const a of anchors) {
                let href = a.href || '';
                if (!href || seen.has(href)) continue;
                seen.add(href);

                const box = a.closest('li, .api_subject_bx, .kin_wrap, .total_wrap, .question_group, div') || a.parentElement;
                const text = clean(box ? box.innerText : a.innerText);
                const title = clean(a.innerText) || clean(a.getAttribute('title')) || text.slice(0, 100);

                let answerCount = 0;
                const answerMatch = text.match(/답변\s*(\d+)|답변수\s*[:：]?\s*(\d+)/i);
                if (answerMatch) answerCount = parseInt(answerMatch[1] || answerMatch[2] || '0', 10);

                let dateText = '';
                const dateMatch = text.match(/(\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}(?:\s+\d{1,2}:\d{2})?|\d+\s*분\s*전|\d+\s*시간\s*전|\d+\s*일\s*전)/);
                if (dateMatch) dateText = dateMatch[1];

                const urlObj = new URL(href);
                const docId = urlObj.searchParams.get('docId') || '';
                const dirId = urlObj.searchParams.get('dirId') || '';
                const id = docId ? docId + '_' + dirId : href;

                rows.push({id, href, title, text, answerCount, dateText});
              }
              SearchBridge.onSearchResults(JSON.stringify(rows));
            })();
        """.trimIndent()
        monitorWeb.evaluateJavascript(js, null)
    }

    inner class SearchBridge {
        @JavascriptInterface
        fun onSearchResults(json: String) {
            runOnUiThread {
                lifecycleScope.launch {
                    handleSearchResults(json)
                }
            }
        }
    }

    private suspend fun handleSearchResults(json: String) {
        val meta = runCatching { JSONObject(monitorWeb.tag as? String ?: "{}") }.getOrDefault(JSONObject())
        val keyword = meta.optString("keyword")
        val recent = meta.optBoolean("recent", true)
        val array = runCatching { JSONArray(json) }.getOrDefault(JSONArray())

        val maxAnswers = maxAnswersInput.text.toString().toIntOrNull() ?: 5
        val hoursLimit = hoursInput.text.toString().toIntOrNull() ?: 48
        val maxItems = if (recent) array.length() else min(3, array.length())

        var sentCount = 0
        for (i in 0 until maxItems) {
            val item = array.optJSONObject(i) ?: continue
            val id = item.optString("id")
            if (id.isBlank() || sentIds.contains(id)) continue

            val answerCount = item.optInt("answerCount", 0)
            if (answerCount > maxAnswers) continue

            val dateText = item.optString("dateText")
            if (!isWithinHours(dateText, hoursLimit)) continue

            val rankLabel = if (recent) "최신순" else "정확도 ${i + 1}위"
            val message = buildString {
                appendLine("지식인 질문 발견")
                appendLine("검색: $rankLabel")
                appendLine("키워드: $keyword")
                appendLine("제목: ${item.optString("title")}")
                appendLine("답변수: $answerCount")
                if (dateText.isNotBlank()) appendLine("등록: $dateText")
                append("질문링크: ${item.optString("href")}")
            }

            val success = sendTelegram(message)
            if (success) {
                sentIds.add(id)
                sentCount++
            }
        }

        if (sentCount > 0) {
            saveSettings()
            status("$keyword · ${if (recent) "최신순" else "정확도 TOP3"} · ${sentCount}건 전송")
        } else {
            status("$keyword · 새 질문 없음")
        }
    }

    private fun isWithinHours(dateText: String, hoursLimit: Int): Boolean {
        if (dateText.isBlank()) return true
        val now = LocalDateTime.now(ZoneId.systemDefault())
        val normalized = dateText.replace(" ", "")

        Regex("""(\d+)분전""").find(normalized)?.let {
            return it.groupValues[1].toLong() <= hoursLimit * 60L
        }
        Regex("""(\d+)시간전""").find(normalized)?.let {
            return it.groupValues[1].toLong() <= hoursLimit
        }
        Regex("""(\d+)일전""").find(normalized)?.let {
            return it.groupValues[1].toLong() * 24L <= hoursLimit
        }

        val formats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy.MM.dd"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd")
        )

        for (format in formats) {
            try {
                val parsed = if (format.toString().contains("HourOfDay")) {
                    LocalDateTime.parse(dateText.trim(), format)
                } else {
                    java.time.LocalDate.parse(dateText.trim(), format).atStartOfDay()
                }
                return Duration.between(parsed, now).toHours() in 0..hoursLimit.toLong()
            } catch (_: Exception) {}
        }
        return true
    }

    private suspend fun sendTelegram(message: String): Boolean = withContext(Dispatchers.IO) {
        val token = botTokenInput.text.toString().trim()
        val chatId = chatIdInput.text.toString().trim()
        if (token.isBlank() || chatId.isBlank()) return@withContext false

        val requestBody = FormBody.Builder()
            .add("chat_id", chatId)
            .add("text", message)
            .add("disable_web_page_preview", "true")
            .build()

        val request = Request.Builder()
            .url("https://api.telegram.org/bot$token/sendMessage")
            .post(requestBody)
            .build()

        runCatching {
            http.newCall(request).execute().use { response -> response.isSuccessful }
        }.getOrDefault(false)
    }

    private fun extractQuestion() {
        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g,' ').trim();
              const titleSelectors = [
                'h1', '.title', '.question_title', '.c-heading__title',
                '[class*="title"]'
              ];
              const bodySelectors = [
                '.question-content', '.question_detail', '.c-heading__content',
                '.se-main-container', '[class*="question"][class*="content"]',
                '[class*="content"]'
              ];

              let title = '';
              for (const s of titleSelectors) {
                const e = document.querySelector(s);
                if (e && clean(e.innerText).length > title.length) title = clean(e.innerText);
              }

              let body = '';
              for (const s of bodySelectors) {
                const list = Array.from(document.querySelectorAll(s));
                for (const e of list) {
                  const t = clean(e.innerText);
                  if (t.length > body.length && t.length < 10000) body = t;
                }
              }

              if (!title) title = clean(document.title);
              if (!body) body = clean(document.body.innerText).slice(0, 7000);

              NaverBridge.onQuestion(JSON.stringify({title, body, url: location.href}));
            })();
        """.trimIndent()
        leftWeb.evaluateJavascript(js, null)
    }

    inner class NaverBridge {
        @JavascriptInterface
        fun onQuestion(json: String) {
            runOnUiThread {
                val obj = runCatching { JSONObject(json) }.getOrDefault(JSONObject())
                questionText = buildString {
                    appendLine("아래 네이버 지식인 질문에 알맞은 답변을 작성해줘.")
                    appendLine()
                    appendLine("제목: ${obj.optString("title")}")
                    appendLine("질문: ${obj.optString("body")}")
                    appendLine("링크: ${obj.optString("url")}")
                }
                toast("질문을 가져왔습니다.")
                status("질문 가져오기 완료")
            }
        }
    }

    private fun sendQuestionToGpt() {
        if (questionText.isBlank()) {
            toast("먼저 질문 다시 가져오기를 눌러 주세요.")
            return
        }
        val escaped = JSONObject.quote(questionText)
        val js = """
            (function() {
              const text = $escaped;
              const candidates = [
                document.querySelector('#prompt-textarea'),
                document.querySelector('textarea'),
                document.querySelector('[contenteditable="true"]')
              ].filter(Boolean);

              const input = candidates[0];
              if (!input) return 'INPUT_NOT_FOUND';

              input.focus();
              if (input.tagName === 'TEXTAREA') {
                const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
                setter.call(input, text);
                input.dispatchEvent(new Event('input', {bubbles:true}));
                input.dispatchEvent(new Event('change', {bubbles:true}));
              } else {
                input.innerHTML = '';
                input.textContent = text;
                input.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:text}));
              }

              setTimeout(() => {
                const send = document.querySelector(
                  'button[data-testid="send-button"], button[aria-label*="Send"], button[aria-label*="보내기"]'
                );
                if (send && !send.disabled) send.click();
              }, 400);
              return 'OK';
            })();
        """.trimIndent()

        rightWeb.evaluateJavascript(js) { result ->
            if (result?.contains("INPUT_NOT_FOUND") == true) {
                toast("ChatGPT 입력창을 찾지 못했습니다.")
            } else {
                toast("GPT로 질문을 보냈습니다.")
                status("GPT 질문 전송 완료")
            }
        }
    }

    private fun extractAnswer() {
        val js = """
            (function() {
              const clean = s => (s || '').trim();
              const selectors = [
                '[data-message-author-role="assistant"]',
                'article[data-testid^="conversation-turn"]',
                '.markdown.prose'
              ];
              let nodes = [];
              for (const s of selectors) {
                const found = Array.from(document.querySelectorAll(s));
                if (found.length) nodes = found;
              }
              const last = nodes[nodes.length - 1];
              const text = last ? clean(last.innerText) : '';
              GptBridge.onAnswer(text);
            })();
        """.trimIndent()
        rightWeb.evaluateJavascript(js, null)
    }

    inner class GptBridge {
        @JavascriptInterface
        fun onAnswer(text: String) {
            runOnUiThread {
                answerText = text.trim()
                if (answerText.isBlank()) {
                    toast("가져올 답변을 찾지 못했습니다.")
                    status("답변 추출 실패")
                } else {
                    toast("답변을 가져왔습니다.")
                    status("답변 가져오기 완료")
                }
            }
        }
    }

    private fun pasteAnswerToNaver() {
        if (answerText.isBlank()) {
            toast("먼저 답변 다시 가져오기를 눌러 주세요.")
            return
        }
        val escaped = JSONObject.quote(answerText)
        val js = """
            (function() {
              const answer = $escaped;

              const clickCandidates = Array.from(document.querySelectorAll('button, a'));
              const answerButton = clickCandidates.find(e =>
                /답변하기|답변 작성|답변등록/.test((e.innerText || e.textContent || '').trim())
              );
              if (answerButton) answerButton.click();

              setTimeout(() => {
                const editors = [
                  document.querySelector('textarea'),
                  document.querySelector('[contenteditable="true"]'),
                  document.querySelector('.se-content'),
                  document.querySelector('[role="textbox"]')
                ].filter(Boolean);

                const editor = editors.find(e => {
                  const r = e.getBoundingClientRect();
                  return r.width > 0 && r.height > 0;
                }) || editors[0];

                if (!editor) {
                  alert('답변 입력창을 찾지 못했습니다. 답변하기를 직접 누른 뒤 다시 시도해 주세요.');
                  return;
                }

                editor.focus();
                if (editor.tagName === 'TEXTAREA' || editor.tagName === 'INPUT') {
                  const proto = editor.tagName === 'TEXTAREA'
                    ? window.HTMLTextAreaElement.prototype
                    : window.HTMLInputElement.prototype;
                  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
                  setter.call(editor, answer);
                  editor.dispatchEvent(new Event('input', {bubbles:true}));
                  editor.dispatchEvent(new Event('change', {bubbles:true}));
                } else {
                  editor.innerHTML = '';
                  const lines = answer.split('\n');
                  for (const line of lines) {
                    const p = document.createElement('p');
                    p.textContent = line || '\u00A0';
                    editor.appendChild(p);
                  }
                  editor.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:answer}));
                }
                editor.scrollIntoView({behavior:'smooth', block:'center'});
              }, 900);
            })();
        """.trimIndent()

        leftWeb.evaluateJavascript(js, null)
        toast("네이버 답변창에 붙여넣기를 시도했습니다.")
        status("네이버 붙여넣기 실행")
    }

    private fun status(value: String) {
        runOnUiThread { statusText.text = value }
    }

    private fun toast(value: String) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        when {
            rightWeb.canGoBack() -> rightWeb.goBack()
            leftWeb.canGoBack() -> leftWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
