package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("step1_layout_settings", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var settingsCard: LinearLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var chatWeb: WebView
    private lateinit var naverWeb: WebView
    private lateinit var verticalDivider: View
    private lateinit var horizontalDivider: View

    private lateinit var naverUrlInput: EditText
    private lateinit var chatUrlInput: EditText
    private lateinit var toggleButton: Button

    private var leftColumnWeight = 0.78f
    private var rightColumnWeight = 1.22f
    private var topWeight = 0.78f
    private var bottomWeight = 1.22f

    private var dragStartX = 0f
    private var dragStartY = 0f
    private var dragStartLeftWeight = leftColumnWeight
    private var dragStartTopWeight = topWeight

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(chatWeb, "chat_last_url")
        configureWebView(naverWeb, "naver_last_url")
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextSize(12f)
            setOnClickListener { action() }
        }

    private fun input(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            setTextSize(13f)
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_ALWAYS
            isVerticalScrollBarEnabled = true
        }

        settingsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleButton = button("◀ 설정창 접기") { toggleSettings() }
        settingsCard.addView(toggleButton, LinearLayout.LayoutParams(-1, dp(46)))

        settingsCard.addView(TextView(this).apply {
            text = "프로그램 설정"
            textSize = 18f
            setTextColor(Color.BLACK)
        })

        settingsCard.addView(TextView(this).apply {
            text = "지식인 페이지 주소"
            textSize = 13f
        })
        naverUrlInput = input("https://m.kin.naver.com/")
        settingsCard.addView(naverUrlInput, LinearLayout.LayoutParams(-1, dp(48)))

        settingsCard.addView(TextView(this).apply {
            text = "ChatGPT 페이지 주소"
            textSize = 13f
        })
        chatUrlInput = input("https://chatgpt.com/")
        settingsCard.addView(chatUrlInput, LinearLayout.LayoutParams(-1, dp(48)))

        settingsCard.addView(
            button("설정 저장") {
                saveSettings()
                Toast.makeText(this, "설정을 저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(46))
        )

        settingsCard.addView(
            button("저장한 주소 열기") {
                naverWeb.loadUrl(normalizeUrl(naverUrlInput.text.toString(), true))
                chatWeb.loadUrl(normalizeUrl(chatUrlInput.text.toString(), false))
                saveSettings()
            },
            LinearLayout.LayoutParams(-1, dp(46))
        )

        settingsCard.addView(
            button("현재 페이지 새로고침") {
                naverWeb.reload()
                chatWeb.reload()
            },
            LinearLayout.LayoutParams(-1, dp(46))
        )

        settingsCard.addView(
            button("설정 초기화") {
                prefs.edit().clear().apply()
                naverUrlInput.setText("https://m.kin.naver.com/")
                chatUrlInput.setText("https://chatgpt.com/")
                leftColumnWeight = 0.78f
                rightColumnWeight = 1.22f
                topWeight = 0.78f
                bottomWeight = 1.22f
                applyAllWeights()
                naverWeb.loadUrl("https://m.kin.naver.com/")
                chatWeb.loadUrl("https://chatgpt.com/")
                Toast.makeText(this, "설정을 초기화했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(46))
        )

        settingsCard.addView(TextView(this).apply {
            text = "설정과 마지막 페이지는 앱을 다시 열어도 유지됩니다.\n왼쪽 위·아래와 오른쪽 페이지는 각각 손가락으로 스크롤할 수 있습니다."
            textSize = 12f
            setPadding(0, dp(10), 0, dp(20))
        })

        settingsScroll.addView(settingsCard, ScrollView.LayoutParams(-1, -2))

        chatWeb = WebView(this)
        naverWeb = WebView(this)

        leftColumn.addView(settingsScroll, LinearLayout.LayoutParams(-1, 0, topWeight))

        horizontalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(170, 170, 170))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dragStartY = event.rawY
                        dragStartTopWeight = topWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val height = max(leftColumn.height, 1)
                        val delta = (event.rawY - dragStartY) / height * 2f
                        topWeight = min(1.8f, max(0.2f, dragStartTopWeight + delta))
                        bottomWeight = 2f - topWeight
                        applyVerticalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        leftColumn.addView(horizontalDivider, LinearLayout.LayoutParams(-1, dp(8)))
        leftColumn.addView(chatWeb, LinearLayout.LayoutParams(-1, 0, bottomWeight))

        root.addView(leftColumn, LinearLayout.LayoutParams(0, -1, leftColumnWeight))

        verticalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(150, 150, 150))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        dragStartX = event.rawX
                        dragStartLeftWeight = leftColumnWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val width = max(root.width, 1)
                        val delta = (event.rawX - dragStartX) / width * 2f
                        leftColumnWeight = min(1.8f, max(0.2f, dragStartLeftWeight + delta))
                        rightColumnWeight = 2f - leftColumnWeight
                        applyHorizontalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        root.addView(verticalDivider, LinearLayout.LayoutParams(dp(8), -1))
        root.addView(naverWeb, LinearLayout.LayoutParams(0, -1, rightColumnWeight))

        setContentView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(webView: WebView, key: String) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_ALWAYS
        webView.setOnTouchListener { view, event ->
            view.parent.requestDisallowInterceptTouchEvent(true)
            when (event.actionMasked) {
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.parent.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                prefs.edit().putString(key, url).apply()
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun normalizeUrl(value: String, isNaver: Boolean): String {
        val text = value.trim()
        if (text.isBlank()) {
            return if (isNaver) "https://m.kin.naver.com/" else "https://chatgpt.com/"
        }
        return if (text.startsWith("http://") || text.startsWith("https://")) {
            text
        } else {
            "https://$text"
        }
    }

    private fun loadSavedPages() {
        val naver = prefs.getString(
            "naver_last_url",
            prefs.getString("naver_home_url", "https://m.kin.naver.com/")
        ) ?: "https://m.kin.naver.com/"

        val chat = prefs.getString(
            "chat_last_url",
            prefs.getString("chat_home_url", "https://chatgpt.com/")
        ) ?: "https://chatgpt.com/"

        naverWeb.loadUrl(naver)
        chatWeb.loadUrl(chat)
    }

    private fun saveSettings() {
        prefs.edit()
            .putString("naver_home_url", normalizeUrl(naverUrlInput.text.toString(), true))
            .putString("chat_home_url", normalizeUrl(chatUrlInput.text.toString(), false))
            .putFloat("left_column_weight", leftColumnWeight)
            .putFloat("top_weight", topWeight)
            .apply()
    }

    private fun restoreSettings() {
        naverUrlInput.setText(
            prefs.getString("naver_home_url", "https://m.kin.naver.com/")
        )
        chatUrlInput.setText(
            prefs.getString("chat_home_url", "https://chatgpt.com/")
        )

        leftColumnWeight = prefs.getFloat("left_column_weight", 0.78f).coerceIn(0.2f, 1.8f)
        rightColumnWeight = 2f - leftColumnWeight

        topWeight = prefs.getFloat("top_weight", 0.78f).coerceIn(0.2f, 1.8f)
        bottomWeight = 2f - topWeight

        applyAllWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsScroll.post { collapseSettings() }
        }
    }

    private fun applyAllWeights() {
        applyHorizontalWeights()
        applyVerticalWeights()
    }

    private fun applyHorizontalWeights() {
        (leftColumn.layoutParams as? LinearLayout.LayoutParams)?.weight = leftColumnWeight
        (naverWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = rightColumnWeight
        leftColumn.requestLayout()
        naverWeb.requestLayout()
    }

    private fun applyVerticalWeights() {
        (settingsScroll.layoutParams as? LinearLayout.LayoutParams)?.weight = topWeight
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight = bottomWeight
        settingsScroll.requestLayout()
        chatWeb.requestLayout()
    }

    private fun toggleSettings() {
        if (settingsCard.childCount <= 1) return
        val currentlyCollapsed = prefs.getBoolean("settings_collapsed", false)
        if (currentlyCollapsed) expandSettings() else collapseSettings()
    }

    private fun collapseSettings() {
        for (i in 1 until settingsCard.childCount) {
            settingsCard.getChildAt(i).visibility = View.GONE
        }
        toggleButton.text = "▶ 설정창 펼치기"
        topWeight = 0.22f
        bottomWeight = 1.78f
        applyVerticalWeights()
        prefs.edit()
            .putBoolean("settings_collapsed", true)
            .putFloat("top_weight", topWeight)
            .apply()
    }

    private fun expandSettings() {
        for (i in 1 until settingsCard.childCount) {
            settingsCard.getChildAt(i).visibility = View.VISIBLE
        }
        toggleButton.text = "◀ 설정창 접기"
        topWeight = prefs.getFloat("expanded_top_weight", 0.78f).coerceIn(0.3f, 1.7f)
        bottomWeight = 2f - topWeight
        applyVerticalWeights()
        prefs.edit()
            .putBoolean("settings_collapsed", false)
            .putFloat("top_weight", topWeight)
            .apply()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            naverWeb.canGoBack() -> naverWeb.goBack()
            chatWeb.canGoBack() -> chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
