package com.rose.knowledgeindual

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Collections
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("knowledge_step2_fixed", MODE_PRIVATE)
    }

    private lateinit var root: LinearLayout
    private lateinit var leftColumn: LinearLayout
    private lateinit var settingsPanel: LinearLayout
    private lateinit var settingsScroll: ScrollView
    private lateinit var settingsContent: LinearLayout
    private lateinit var chatWeb: WebView
    private lateinit var naverWeb: WebView
    private lateinit var monitorWeb: WebView
    private lateinit var verticalDivider: View
    private lateinit var horizontalDivider: View

    private lateinit var naverUrlInput: EditText
    private lateinit var chatUrlInput: EditText
    private lateinit var keywordInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var hoursInput: EditText
    private lateinit var maxAnswersInput: EditText
    private lateinit var keywordListText: TextView
    private lateinit var statusText: TextView
    private lateinit var resultContainer: LinearLayout
    private lateinit var toggleSettingsButton: Button

    private val keywords = mutableListOf<String>()
    private val seenQuestionIds = Collections.synchronizedSet(mutableSetOf<String>())

    private var leftColumnWeight = 0.75f
    private var rightColumnWeight = 1.25f
    private var settingsHeightWeight = 0.72f
    private var chatHeightWeight = 1.28f

    private var startX = 0f
    private var startLeftWeight = 0.75f
    private var startY = 0f
    private var startSettingsWeight = 0.72f

    private var monitorJob: Job? = null
    private var keywordCursor = 0
    private var searchRecent = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSettings()
        configureWebView(chatWeb, PageType.CHAT)
        configureWebView(naverWeb, PageType.NAVER)
        configureWebView(monitorWeb, PageType.MONITOR)
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        saveSettings()
        super.onDestroy()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun input(hintText: String): EditText =
        EditText(this).apply {
            hint = hintText
            isSingleLine = true
            textSize = 13f
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.WHITE)
        }

        leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(248, 249, 250))
        }

        toggleSettingsButton = button("◀ 설정 접기") { toggleSettingsPanel() }
        settingsPanel.addView(toggleSettingsButton, LinearLayout.LayoutParams(-1, dp(44)))

        settingsScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
        }

        settingsContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(16))
        }

        settingsScroll.addView(
            settingsContent,
            ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT
            )
        )
        settingsPanel.addView(settingsScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        addPageSettings()
        addSearchSettings()
        addResultArea()

        chatWeb = WebView(this)
        naverWeb = WebView(this)
        monitorWeb = WebView(this).apply {
            visibility = View.GONE
        }

        leftColumn.addView(
            settingsPanel,
            LinearLayout.LayoutParams(-1, 0, settingsHeightWeight)
        )

        horizontalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(155, 155, 155))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startY = event.rawY
                        startSettingsWeight = settingsHeightWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val height = max(leftColumn.height, 1)
                        val delta = (event.rawY - startY) / height * 2f
                        settingsHeightWeight =
                            min(1.7f, max(0.3f, startSettingsWeight + delta))
                        chatHeightWeight = 2f - settingsHeightWeight
                        applyVerticalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        leftColumn.addView(horizontalDivider, LinearLayout.LayoutParams(-1, dp(10)))
        leftColumn.addView(chatWeb, LinearLayout.LayoutParams(-1, 0, chatHeightWeight))

        root.addView(leftColumn, LinearLayout.LayoutParams(0, -1, leftColumnWeight))

        verticalDivider = View(this).apply {
            setBackgroundColor(Color.rgb(135, 135, 135))
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = event.rawX
                        startLeftWeight = leftColumnWeight
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val width = max(root.width, 1)
                        val delta = (event.rawX - startX) / width * 2f
                        leftColumnWeight =
                            min(1.6f, max(0.4f, startLeftWeight + delta))
                        rightColumnWeight = 2f - leftColumnWeight
                        applyHorizontalWeights()
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        saveSettings()
                        true
                    }
                    else -> false
                }
            }
        }

        root.addView(verticalDivider, LinearLayout.LayoutParams(dp(10), -1))
        root.addView(naverWeb, LinearLayout.LayoutParams(0, -1, rightColumnWeight))
        root.addView(monitorWeb, LinearLayout.LayoutParams(1, 1))

        setContentView(root)
    }

    private fun addPageSettings() {
        settingsContent.addView(TextView(this).apply {
            text = "페이지 설정"
            textSize = 15f
            setTextColor(Color.rgb(20, 90, 190))
        })

        settingsContent.addView(TextView(this).apply {
            text = "지식인 페이지 주소"
            textSize = 13f
        })

        naverUrlInput = input("https://m.kin.naver.com/")
        settingsContent.addView(naverUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        settingsContent.addView(
            button("지식인 주소 저장하고 열기") {
                naverWeb.loadUrl(normalizeUrl(naverUrlInput.text.toString(), true))
                saveSettings()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        settingsContent.addView(TextView(this).apply {
            text = "ChatGPT 페이지 주소"
            textSize = 13f
        })

        chatUrlInput = input("https://chatgpt.com/")
        settingsContent.addView(chatUrlInput, LinearLayout.LayoutParams(-1, dp(46)))

        settingsContent.addView(
            button("ChatGPT 주소 저장하고 열기") {
                chatWeb.loadUrl(normalizeUrl(chatUrlInput.text.toString(), false))
                saveSettings()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )
    }

    private fun addSearchSettings() {
        settingsContent.addView(TextView(this).apply {
            text = "2단계 검색 설정"
            textSize = 15f
            setTextColor(Color.rgb(20, 90, 190))
            setPadding(0, dp(12), 0, dp(4))
        })

        keywordInput = input("검색 키워드 입력")
        settingsContent.addView(keywordInput, LinearLayout.LayoutParams(-1, dp(46)))

        val keywordButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        keywordButtons.addView(
            button("키워드 추가") { addKeyword() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        keywordButtons.addView(
            button("마지막 삭제") { removeLastKeyword() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        settingsContent.addView(keywordButtons)

        keywordListText = TextView(this).apply {
            textSize = 12f
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setBackgroundColor(Color.WHITE)
        }
        settingsContent.addView(keywordListText, LinearLayout.LayoutParams(-1, dp(92)))

        intervalInput = input("검색 주기(초)")
        hoursInput = input("등록 후 제한 시간")
        maxAnswersInput = input("최대 답변 수")

        settingsContent.addView(intervalInput, LinearLayout.LayoutParams(-1, dp(44)))
        settingsContent.addView(hoursInput, LinearLayout.LayoutParams(-1, dp(44)))
        settingsContent.addView(maxAnswersInput, LinearLayout.LayoutParams(-1, dp(44)))

        val monitorButtons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        monitorButtons.addView(
            button("검색 시작") { startMonitoring() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        monitorButtons.addView(
            button("검색 중지") { stopMonitoring() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        settingsContent.addView(monitorButtons)

        settingsContent.addView(
            button("전체 설정 저장") {
                saveSettings()
                Toast.makeText(this, "설정을 저장했습니다.", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(-1, dp(44))
        )

        statusText = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        settingsContent.addView(statusText)
    }

    private fun addResultArea() {
        settingsContent.addView(TextView(this).apply {
            text = "감지된 질문"
            textSize = 15f
            setTextColor(Color.rgb(20, 90, 190))
            setPadding(0, dp(10), 0, dp(4))
        })

        resultContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        settingsContent.addView(resultContainer, LinearLayout.LayoutParams(-1, -2))
    }

    private enum class PageType {
        CHAT, NAVER, MONITOR
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun configureWebView(webView: WebView, pageType: PageType) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true
        webView.overScrollMode = View.OVER_SCROLL_ALWAYS
        webView.setOnTouchListener { view, event ->
            view.parent?.requestDisallowInterceptTouchEvent(true)
            if (
                event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        if (pageType == PageType.MONITOR) {
            webView.addJavascriptInterface(SearchBridge(), "SearchBridge")
        }

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                when (pageType) {
                    PageType.NAVER ->
                        prefs.edit().putString("naver_last_url", url).apply()
                    PageType.CHAT ->
                        prefs.edit().putString("chat_last_url", url).apply()
                    PageType.MONITOR ->
                        view.postDelayed({ parseSearchPage() }, 900)
                }
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun normalizeUrl(value: String, isNaver: Boolean): String {
        val fallback =
            if (isNaver) "https://m.kin.naver.com/" else "https://chatgpt.com/"
        val text = value.trim()
        return when {
            text.isBlank() -> fallback
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun loadSavedPages() {
        val naverHome =
            prefs.getString("naver_home_url", "https://m.kin.naver.com/")
                ?: "https://m.kin.naver.com/"
        val chatHome =
            prefs.getString("chat_home_url", "https://chatgpt.com/")
                ?: "https://chatgpt.com/"

        naverWeb.loadUrl(
            prefs.getString("naver_last_url", naverHome) ?: naverHome
        )
        chatWeb.loadUrl(
            prefs.getString("chat_last_url", chatHome) ?: chatHome
        )
    }

    private fun addKeyword() {
        val value = keywordInput.text.toString().trim()
        if (value.isBlank()) return
        if (!keywords.contains(value)) {
            keywords.add(value)
        }
        keywordInput.setText("")
        renderKeywords()
        saveSettings()
    }

    private fun removeLastKeyword() {
        if (keywords.isNotEmpty()) {
            keywords.removeAt(keywords.lastIndex)
        }
        renderKeywords()
        saveSettings()
    }

    private fun renderKeywords() {
        keywordListText.text =
            if (keywords.isEmpty()) {
                "등록된 키워드 없음"
            } else {
                keywords.mapIndexed { index, value ->
                    "${index + 1}. $value"
                }.joinToString("\n")
            }
    }

    private fun startMonitoring() {
        saveSettings()

        if (keywords.isEmpty()) {
            Toast.makeText(
                this,
                "검색 키워드를 먼저 추가해 주세요.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        monitorJob?.cancel()
        monitorJob = lifecycleScope.launch {
            statusText.text = "검색 시작"

            while (isActive) {
                val keyword = keywords[keywordCursor % keywords.size]
                keywordCursor = (keywordCursor + 1) % keywords.size

                val modeText =
                    if (searchRecent) "최신순" else "정확도 TOP3"
                statusText.text = "$keyword · $modeText 검색 중"

                loadSearch(keyword, searchRecent)
                searchRecent = !searchRecent

                val seconds =
                    max(1, intervalInput.text.toString().toIntOrNull() ?: 1)
                delay(seconds * 1000L)
            }
        }
    }

    private fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
        statusText.text = "검색 중지"
    }

    private fun loadSearch(keyword: String, recent: Boolean) {
        val encoded = URLEncoder.encode(keyword, "UTF-8")
        val sort = if (recent) "date" else "none"
        val url =
            "https://search.naver.com/search.naver?where=kin&query=$encoded&sort=$sort"

        monitorWeb.tag = JSONObject()
            .put("keyword", keyword)
            .put("recent", recent)
            .toString()

        monitorWeb.loadUrl(url)
    }

    private fun parseSearchPage() {
        val js = """
            (function() {
              const clean = s => (s || '').replace(/\s+/g, ' ').trim();
              const selector = [
                'a[href*="kin.naver.com/qna/detail.naver"]',
                'a[href*="m.kin.naver.com/mobile/qna/detail.naver"]',
                'a[href*="/qna/detail.naver"]'
              ].join(',');

              const anchors = Array.from(document.querySelectorAll(selector));
              const seen = new Set();
              const rows = [];

              for (const a of anchors) {
                const href = a.href || '';
                if (!href || seen.has(href)) continue;
                seen.add(href);

                const box =
                  a.closest('li, .api_subject_bx, .kin_wrap, .total_wrap, .question_group, .bx, div')
                  || a.parentElement;

                const text = clean(box ? box.innerText : a.innerText);
                const title =
                  clean(a.innerText)
                  || clean(a.getAttribute('title'))
                  || text.slice(0, 120);

                let answerCount = 0;
                const answerMatch =
                  text.match(/답변\s*(\d+)|답변수\s*[:：]?\s*(\d+)/i);

                if (answerMatch) {
                  answerCount =
                    parseInt(answerMatch[1] || answerMatch[2] || '0', 10);
                }

                let dateText = '';
                const dateMatch = text.match(
                  /(\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}(?:\s+\d{1,2}:\d{2})?|\d+\s*분\s*전|\d+\s*시간\s*전|\d+\s*일\s*전)/
                );

                if (dateMatch) dateText = dateMatch[1];

                let id = href;
                try {
                  const u = new URL(href);
                  const docId = u.searchParams.get('docId') || '';
                  const dirId = u.searchParams.get('dirId') || '';
                  if (docId) id = docId + '_' + dirId;
                } catch (_) {}

                rows.push({
                  id,
                  href,
                  title,
                  answerCount,
                  dateText
                });
              }

              SearchBridge.onSearchResults(JSON.stringify(rows));
            })();
        """.trimIndent()

        monitorWeb.evaluateJavascript(js, null)
    }

    inner class SearchBridge {
        @JavascriptInterface
        fun onSearchResults(json: String) {
            runOnUiThread {
                handleSearchResults(json)
            }
        }
    }

    private fun handleSearchResults(json: String) {
        val meta =
            runCatching {
                JSONObject(monitorWeb.tag as? String ?: "{}")
            }.getOrElse {
                JSONObject()
            }

        val keyword = meta.optString("keyword")
        val recent = meta.optBoolean("recent", true)

        val rows =
            runCatching {
                JSONArray(json)
            }.getOrElse {
                JSONArray()
            }

        val maxAnswers =
            maxAnswersInput.text.toString().toIntOrNull() ?: 5
        val hoursLimit =
            hoursInput.text.toString().toIntOrNull() ?: 48
        val countLimit =
            if (recent) rows.length() else min(3, rows.length())

        var added = 0

        for (index in 0 until countLimit) {
            val item = rows.optJSONObject(index) ?: continue
            val id = item.optString("id")

            if (id.isBlank() || seenQuestionIds.contains(id)) continue

            val answerCount = item.optInt("answerCount", 0)
            if (answerCount > maxAnswers) continue

            val dateText = item.optString("dateText")
            if (!isWithinHours(dateText, hoursLimit)) continue

            val mode =
                if (recent) "최신순" else "정확도 ${index + 1}위"

            addQuestionCard(
                keyword = keyword,
                mode = mode,
                title = item.optString("title"),
                url = item.optString("href"),
                answerCount = answerCount,
                dateText = dateText
            )

            seenQuestionIds.add(id)
            added++
        }

        if (added > 0) {
            statusText.text = "$keyword · ${added}건 감지"
            saveSettings()
        } else {
            statusText.text = "$keyword · 새 질문 없음"
        }
    }

    private fun addQuestionCard(
        keyword: String,
        mode: String,
        title: String,
        url: String,
        answerCount: Int,
        dateText: String
    ) {
        val card = Button(this).apply {
            isAllCaps = false
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            text = buildString {
                append("[$mode] $keyword\n")
                append(title.ifBlank { "제목 없음" })
                append("\n답변 $answerCount")
                if (dateText.isNotBlank()) {
                    append(" · $dateText")
                }
            }
            textSize = 11f
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setOnClickListener {
                naverWeb.loadUrl(url)
            }
        }

        resultContainer.addView(
            card,
            0,
            LinearLayout.LayoutParams(-1, dp(88))
        )

        while (resultContainer.childCount > 30) {
            resultContainer.removeViewAt(
                resultContainer.childCount - 1
            )
        }
    }

    private fun isWithinHours(
        dateText: String,
        hoursLimit: Int
    ): Boolean {
        if (dateText.isBlank()) return true

        val now = LocalDateTime.now(ZoneId.systemDefault())
        val normalized = dateText.replace(" ", "")

        Regex("""(\d+)분전""").find(normalized)?.let { match ->
            return match.groupValues[1].toLong() <= hoursLimit * 60L
        }

        Regex("""(\d+)시간전""").find(normalized)?.let { match ->
            return match.groupValues[1].toLong() <= hoursLimit
        }

        Regex("""(\d+)일전""").find(normalized)?.let { match ->
            return match.groupValues[1].toLong() * 24L <= hoursLimit
        }

        val dateTimeFormats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm")
        )

        for (format in dateTimeFormats) {
            try {
                val parsed = LocalDateTime.parse(dateText.trim(), format)
                val hours = Duration.between(parsed, now).toHours()
                return hours in 0..hoursLimit.toLong()
            } catch (_: Exception) {
            }
        }

        val dateFormats = listOf(
            DateTimeFormatter.ofPattern("yyyy.MM.dd"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd")
        )

        for (format in dateFormats) {
            try {
                val parsed =
                    LocalDate.parse(dateText.trim(), format).atStartOfDay()
                val hours = Duration.between(parsed, now).toHours()
                return hours in 0..hoursLimit.toLong()
            } catch (_: Exception) {
            }
        }

        return true
    }

    private fun saveSettings() {
        prefs.edit()
            .putString(
                "naver_home_url",
                normalizeUrl(naverUrlInput.text.toString(), true)
            )
            .putString(
                "chat_home_url",
                normalizeUrl(chatUrlInput.text.toString(), false)
            )
            .putFloat("left_column_weight", leftColumnWeight)
            .putFloat("settings_height_weight", settingsHeightWeight)
            .putString("keywords", JSONArray(keywords).toString())
            .putInt(
                "interval_seconds",
                intervalInput.text.toString().toIntOrNull() ?: 1
            )
            .putInt(
                "hours_limit",
                hoursInput.text.toString().toIntOrNull() ?: 48
            )
            .putInt(
                "max_answers",
                maxAnswersInput.text.toString().toIntOrNull() ?: 5
            )
            .putStringSet("seen_ids", seenQuestionIds.toSet())
            .apply()
    }

    private fun restoreSettings() {
        naverUrlInput.setText(
            prefs.getString(
                "naver_home_url",
                "https://m.kin.naver.com/"
            )
        )

        chatUrlInput.setText(
            prefs.getString(
                "chat_home_url",
                "https://chatgpt.com/"
            )
        )

        intervalInput.setText(
            prefs.getInt("interval_seconds", 1).toString()
        )
        hoursInput.setText(
            prefs.getInt("hours_limit", 48).toString()
        )
        maxAnswersInput.setText(
            prefs.getInt("max_answers", 5).toString()
        )

        keywords.clear()
        val savedKeywords =
            runCatching {
                JSONArray(prefs.getString("keywords", "[]") ?: "[]")
            }.getOrElse {
                JSONArray()
            }

        for (index in 0 until savedKeywords.length()) {
            val value = savedKeywords.optString(index)
            if (value.isNotBlank()) {
                keywords.add(value)
            }
        }
        renderKeywords()

        seenQuestionIds.addAll(
            prefs.getStringSet("seen_ids", emptySet()) ?: emptySet()
        )

        leftColumnWeight =
            prefs.getFloat("left_column_weight", 0.75f)
                .coerceIn(0.4f, 1.6f)
        rightColumnWeight = 2f - leftColumnWeight

        settingsHeightWeight =
            prefs.getFloat("settings_height_weight", 0.72f)
                .coerceIn(0.3f, 1.7f)
        chatHeightWeight = 2f - settingsHeightWeight

        applyHorizontalWeights()
        applyVerticalWeights()

        if (prefs.getBoolean("settings_collapsed", false)) {
            settingsPanel.post {
                collapseSettings()
            }
        }
    }

    private fun applyHorizontalWeights() {
        if (!::leftColumn.isInitialized || !::naverWeb.isInitialized) return

        (leftColumn.layoutParams as? LinearLayout.LayoutParams)?.weight =
            leftColumnWeight
        (naverWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            rightColumnWeight

        leftColumn.requestLayout()
        naverWeb.requestLayout()
    }

    private fun applyVerticalWeights() {
        if (!::settingsPanel.isInitialized || !::chatWeb.isInitialized) return

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            settingsHeightWeight
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            chatHeightWeight

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun toggleSettingsPanel() {
        val collapsed =
            prefs.getBoolean("settings_collapsed", false)

        if (collapsed) {
            expandSettings()
        } else {
            collapseSettings()
        }
    }

    private fun collapseSettings() {
        settingsScroll.visibility = View.GONE

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            0.16f
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            1.84f

        toggleSettingsButton.text = "▶ 설정 펼치기"

        prefs.edit()
            .putBoolean("settings_collapsed", true)
            .apply()

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    private fun expandSettings() {
        settingsScroll.visibility = View.VISIBLE

        (settingsPanel.layoutParams as? LinearLayout.LayoutParams)?.weight =
            settingsHeightWeight
        (chatWeb.layoutParams as? LinearLayout.LayoutParams)?.weight =
            chatHeightWeight

        toggleSettingsButton.text = "◀ 설정 접기"

        prefs.edit()
            .putBoolean("settings_collapsed", false)
            .apply()

        settingsPanel.requestLayout()
        chatWeb.requestLayout()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            naverWeb.canGoBack() -> naverWeb.goBack()
            chatWeb.canGoBack() -> chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
