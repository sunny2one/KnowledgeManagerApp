# Blog Activity Manager v1.0

Android Kotlin + Jetpack Compose + Room + DataStore + AccessibilityService 프로젝트입니다.

## 빌드
1. 저장소 최상단에 `.github`, `app`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`가 보이도록 업로드합니다.
2. GitHub `Actions` → `Build Android APK` → `Run workflow`를 누릅니다.
3. 완료 후 Artifacts의 `BlogActivityManager-v1.0`을 내려받습니다.

## 사용 전 필수
- 앱에서 키워드와 댓글 문구를 등록합니다.
- 접근성 서비스에서 Blog Activity Manager를 허용합니다.
- 처음에는 반드시 테스트 모드로 실행합니다.
- 네이버 블로그 앱 버전에 따라 접근성 노드 문자열과 검색 결과 구조가 달라질 수 있습니다. 로그를 확인해 `NaverNodeTexts.kt`와 `BlogAccessibilityService.kt`의 탐색 규칙을 조정해야 할 수 있습니다.

## 안전 동작
- 캡차, 본인인증, 이용 제한은 우회하지 않고 중지합니다.
- 댓글 등록 결과가 불확실하면 재등록하지 않고 `RESULT_UNCONFIRMED`로 남깁니다.
- 좋아요 상태를 확인할 수 없으면 반복 클릭하지 않습니다.

## 한계
접근성 서비스는 앱 화면 구조에 의존합니다. 이 프로젝트는 빌드 가능한 전체 구조와 상태 머신을 제공하지만, 실제 기기에서 네이버 앱의 노드가 노출되는 방식에 따라 검색 결과 게시글 판별과 좋아요 상태 확인을 추가 조정해야 할 수 있습니다.
