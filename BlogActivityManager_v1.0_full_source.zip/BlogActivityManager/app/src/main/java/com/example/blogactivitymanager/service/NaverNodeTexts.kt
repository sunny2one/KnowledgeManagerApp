package com.example.blogactivitymanager.service

object NaverNodeTexts {
    const val NAVER_BLOG_PACKAGE = "com.nhn.android.blog"
    val SEARCH = listOf("검색")
    val SEARCH_INPUT = listOf("검색어를 입력", "검색어 입력", "검색")
    val BLOG_TAB = listOf("블로그")
    val LATEST = listOf("최신순")
    val LIKE = listOf("좋아요", "공감", "하트", "like", "heart")
    val LIKED = listOf("좋아요 취소", "공감 취소", "선택됨")
    val COMMENT = listOf("댓글", "댓글 쓰기", "댓글 입력", "첫 번째 댓글을 남겨주세요")
    val COMMENT_INPUT = listOf("댓글을 입력해주세요", "댓글을 입력해주세요.", "내용을 입력해주세요", "댓글 쓰기")
    val REGISTER = listOf("등록", "작성", "확인")
    val COMMENT_SUCCESS = listOf("등록되었습니다", "작성되었습니다")
    val BLOCKED = listOf("잠시 후 다시 이용", "이용이 제한", "비정상적인 접근", "보안 확인", "본인인증", "자동입력 방지", "로그인이 필요", "네트워크 연결 확인")
    val PRIVATE_OR_DELETED = listOf("비공개", "삭제된 게시글", "존재하지 않는 게시글")
}
