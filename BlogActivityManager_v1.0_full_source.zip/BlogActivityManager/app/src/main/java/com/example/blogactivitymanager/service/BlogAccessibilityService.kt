package com.example.blogactivitymanager.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.blogactivitymanager.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

class BlogAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val db by lazy { AppDatabase.get(this) }
    private val store by lazy { SettingsStore(this) }
    @Volatile private var loopStarted = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (AutomationState.state.value.running && !loopStarted) {
            loopStarted = true
            scope.launch { runLoop() }
        }
    }
    override fun onInterrupt() = stopNow("접근성 서비스 중단")
    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private suspend fun runLoop() {
        try {
            while (AutomationState.state.value.running && !AutomationState.stopRequested) {
                waitWhilePaused()
                val settings = store.settings.first()
                if (!settings.likeEnabled && !settings.commentEnabled) return stopWith("좋아요 또는 댓글 기능을 하나 이상 활성화해주세요")
                if (!withinSchedule(settings)) {
                    update("운영시간 대기", "")
                    delay(30_000)
                    continue
                }
                val today = today()
                val stats = db.dao().getDailyStats(today) ?: DailyStatsEntity(today)
                if (stats.processedCount >= settings.dailyPostLimit) return stopWith("하루 최대 게시글 수 도달")

                val keyword = nextKeyword(settings, today) ?: return stopWith("모든 키워드 목표 완료")
                val comments = db.dao().getEnabledComments()
                if (settings.commentEnabled && comments.isEmpty()) return stopWith("사용할 댓글 문구가 없습니다")
                val comment = chooseComment(comments, settings)

                val started = System.currentTimeMillis()
                val target = Random.nextInt(settings.minSeconds, settings.maxSeconds + 1)
                AutomationState.state.value = AutomationState.state.value.copy(currentKeyword = keyword.keyword, todayGoal = settings.dailyPostLimit)

                if (!navigateToSearch(keyword.keyword)) {
                    recordFailure(keyword.keyword, started, "검색 흐름 실패")
                    handleError(settings, "검색 흐름 실패")
                    continue
                }
                val post = openFirstUnprocessedPost(keyword.keyword)
                if (post == null) {
                    recordFailure(keyword.keyword, started, "미처리 게시글을 찾지 못함")
                    handleError(settings, "게시글 선택 실패")
                    continue
                }
                val postId = post.first
                val postTitle = post.second
                val blogName = post.third
                if (db.dao().latestHistory(postId)?.let { it.overallResult == "COMPLETE" } == true) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    delay(1500)
                    continue
                }

                val root = rootInActiveWindow
                if (containsAny(root, NaverNodeTexts.BLOCKED)) return stopWith("보안 또는 이용 제한 화면 감지")
                if (containsAny(root, NaverNodeTexts.PRIVATE_OR_DELETED)) {
                    saveHistory(postId, postTitle, blogName, keyword.keyword, "BUTTON_NOT_FOUND", "NOT_AVAILABLE", "SKIPPED", "비공개 또는 삭제", started, settings.testMode)
                    finishPost(keyword, settings, stats, false, false, true)
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    continue
                }

                var likeResult = if (settings.likeEnabled && stats.likeSuccessCount < settings.dailyLikeLimit) processLike(settings) else "DISABLED"
                var commentResult = if (settings.commentEnabled && stats.commentSuccessCount < settings.dailyCommentLimit) processComment(settings, comment?.content.orEmpty()) else "DISABLED"
                val overall = resultOf(likeResult, commentResult)

                waitUntilTarget(started, target)
                saveHistory(postId, postTitle, blogName, keyword.keyword, likeResult, commentResult, overall, "", started, settings.testMode, comment?.content.orEmpty())
                finishPost(keyword, settings, stats, likeResult == "SUCCESS", commentResult == "SUCCESS", overall == "SKIPPED")
                performGlobalAction(GLOBAL_ACTION_BACK)
                delay(2000)

                if (settings.restEnabled && AutomationState.state.value.todayProcessed > 0 && AutomationState.state.value.todayProcessed % settings.restEvery == 0) {
                    val minutes = Random.nextInt(settings.restMinMinutes, settings.restMaxMinutes + 1)
                    update("휴식 ${minutes}분", keyword.keyword)
                    safeDelay(minutes * 60L)
                }
                if (AutomationState.finishCurrentThenStop) return stopWith("운영 종료시간 도달")
            }
        } catch (t: Throwable) {
            log("ERROR", "LOOP", t.message ?: t.javaClass.simpleName)
            stopWith("오류로 중지")
        } finally { loopStarted = false }
    }

    private suspend fun navigateToSearch(keyword: String): Boolean {
        update("검색 버튼 탐색", keyword)
        val search = waitNode(NaverNodeTexts.SEARCH, 3) ?: return false
        if (!clickNode(search)) return false
        delay(1000)
        val input = waitEditableOrText(NaverNodeTexts.SEARCH_INPUT, 3) ?: return false
        if (!setText(input, keyword)) return false
        input.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER)
        delay(Random.nextLong(3_000, 10_001))
        waitNode(NaverNodeTexts.BLOG_TAB, 3)?.let { clickNode(it); delay(1200) }
        waitNode(NaverNodeTexts.LATEST, 3)?.let { clickNode(it); delay(Random.nextLong(3_000, 10_001)) }
        return rootInActiveWindow != null
    }

    private suspend fun openFirstUnprocessedPost(keyword: String): Triple<String,String,String>? {
        update("미처리 게시글 선택", keyword)
        val root = rootInActiveWindow ?: return null
        val candidates = clickableTextNodes(root).filterNot { nodeText(it).contains("검색") || nodeText(it).contains("최신순") || nodeText(it).contains("블로그") }
        for (node in candidates.take(20)) {
            val title = nodeText(node).trim()
            if (title.length < 4) continue
            val id = sha256("$keyword|$title")
            val old = db.dao().latestHistory(id)
            if (old?.overallResult == "COMPLETE") continue
            if (clickNode(node)) {
                delay(Random.nextLong(5_000, 15_001))
                return Triple(id, title, "")
            }
        }
        return null
    }

    private suspend fun processLike(settings: AppSettings): String {
        update("좋아요 확인", AutomationState.state.value.currentKeyword)
        val node = waitNode(NaverNodeTexts.LIKE, 2) ?: return "BUTTON_NOT_FOUND"
        val desc = nodeText(node)
        if (node.isSelected || node.isChecked || NaverNodeTexts.LIKED.any { desc.contains(it, true) }) return "ALREADY_LIKED"
        if (settings.testMode) return "TEST_ONLY"
        delay(Random.nextLong(3_000, 8_001))
        if (!clickNode(node)) return "FAILED"
        delay(Random.nextLong(2_000, 6_001))
        val after = waitNode(NaverNodeTexts.LIKE + NaverNodeTexts.LIKED, 2)
        return if (after != null && (after.isSelected || after.isChecked || NaverNodeTexts.LIKED.any { nodeText(after).contains(it, true) })) "SUCCESS" else "FAILED"
    }

    private suspend fun processComment(settings: AppSettings, text: String): String {
        update("댓글 확인", AutomationState.state.value.currentKeyword)
        val button = waitNode(NaverNodeTexts.COMMENT, 2) ?: return "NOT_AVAILABLE"
        if (!clickNode(button)) return "FAILED"
        delay(Random.nextLong(3_000, 8_001))
        val input = waitEditableOrText(NaverNodeTexts.COMMENT_INPUT, 3) ?: return "INPUT_NOT_FOUND"
        if (!setText(input, text)) return "INPUT_NOT_FOUND"
        delay(Random.nextLong(10_000, 25_001))
        val register = waitNode(NaverNodeTexts.REGISTER, 3) ?: return "REGISTER_NOT_FOUND"
        if (settings.testMode) {
            setText(input, "")
            performGlobalAction(GLOBAL_ACTION_BACK)
            return "TEST_ONLY"
        }
        if (!register.isEnabled || !clickNode(register)) return "FAILED"
        delay(Random.nextLong(5_000, 15_001))
        val root = rootInActiveWindow
        val confirmed = containsAny(root, NaverNodeTexts.COMMENT_SUCCESS) || findEditable(root)?.text.isNullOrEmpty()
        return if (confirmed) "SUCCESS" else "RESULT_UNCONFIRMED"
    }

    private suspend fun nextKeyword(settings: AppSettings, date: String): KeywordEntity? {
        val all = db.dao().getKeywords().filter { it.enabled }
        if (all.isEmpty()) return null
        val normalized = all.map {
            if (it.lastCountDate != date) {
                val reset = it.copy(todayCount = 0, lastCountDate = date, updatedAt = System.currentTimeMillis())
                db.dao().updateKeyword(reset); reset
            } else it
        }
        val eligible = normalized.filter { it.todayCount < it.dailyTarget }
        if (eligible.isEmpty()) return null
        val idx = settings.currentKeywordIndex.mod(eligible.size)
        return eligible[idx]
    }

    private suspend fun chooseComment(comments: List<CommentTemplateEntity>, settings: AppSettings): CommentTemplateEntity? {
        if (comments.isEmpty()) return null
        return if (settings.commentMode == "RANDOM") comments.random() else comments[settings.currentCommentIndex.mod(comments.size)]
    }

    private suspend fun finishPost(keyword: KeywordEntity, settings: AppSettings, stats: DailyStatsEntity, like: Boolean, comment: Boolean, skipped: Boolean) {
        val updatedKeyword = keyword.copy(todayCount = keyword.todayCount + 1, lastCountDate = today(), updatedAt = System.currentTimeMillis())
        db.dao().updateKeyword(updatedKeyword)
        val updatedStats = stats.copy(
            processedCount = stats.processedCount + 1,
            likeSuccessCount = stats.likeSuccessCount + if (like) 1 else 0,
            commentSuccessCount = stats.commentSuccessCount + if (comment) 1 else 0,
            skipCount = stats.skipCount + if (skipped) 1 else 0,
            failureCount = stats.failureCount + if (!like && !comment && !skipped) 1 else 0
        )
        db.dao().upsertDailyStats(updatedStats)
        store.save(settings.copy(currentKeywordIndex = settings.currentKeywordIndex + 1, currentCommentIndex = settings.currentCommentIndex + 1))
        val s = AutomationState.state.value
        AutomationState.state.value = s.copy(
            todayProcessed = updatedStats.processedCount,
            likeSuccess = updatedStats.likeSuccessCount,
            commentSuccess = updatedStats.commentSuccessCount,
            skipped = updatedStats.skipCount,
            errors = updatedStats.failureCount,
            status = "게시글 처리 완료",
            elapsedSeconds = 0,
            remainingSeconds = 0
        )
    }

    private fun resultOf(like: String, comment: String): String = when {
        like == "RESULT_UNCONFIRMED" || comment == "RESULT_UNCONFIRMED" -> "NEEDS_REVIEW"
        like in setOf("SUCCESS","ALREADY_LIKED","BUTTON_NOT_FOUND","DISABLED","TEST_ONLY") && comment in setOf("SUCCESS","NOT_AVAILABLE","DISABLED","TEST_ONLY") -> "COMPLETE"
        like == "BUTTON_NOT_FOUND" && comment == "NOT_AVAILABLE" -> "SKIPPED"
        like == "FAILED" && comment == "FAILED" -> "FAILED"
        else -> "PARTIAL_COMPLETE"
    }

    private suspend fun waitUntilTarget(started: Long, targetSeconds: Int) {
        while (true) {
            waitWhilePaused()
            if (AutomationState.stopRequested) return
            val elapsed = ((System.currentTimeMillis() - started) / 1000).toInt()
            val remain = targetSeconds - elapsed
            AutomationState.state.value = AutomationState.state.value.copy(elapsedSeconds = elapsed, remainingSeconds = remain.coerceAtLeast(0))
            if (remain <= 0) return
            delay(1000)
        }
    }

    private suspend fun safeDelay(seconds: Long) {
        var left = seconds
        while (left > 0 && !AutomationState.stopRequested) {
            waitWhilePaused(); delay(1000); left--
        }
    }

    private suspend fun waitWhilePaused() {
        while (AutomationState.pauseRequested && !AutomationState.stopRequested) {
            AutomationState.state.value = AutomationState.state.value.copy(paused = true, status = "일시정지")
            delay(500)
        }
        if (!AutomationState.stopRequested) AutomationState.state.value = AutomationState.state.value.copy(paused = false)
    }

    private fun withinSchedule(s: AppSettings): Boolean {
        if (!s.scheduleEnabled) return true
        val c = Calendar.getInstance()
        val day = when (c.get(Calendar.DAY_OF_WEEK)) { Calendar.MONDAY->1; Calendar.TUESDAY->2; Calendar.WEDNESDAY->3; Calendar.THURSDAY->4; Calendar.FRIDAY->5; Calendar.SATURDAY->6; else->7 }
        if (day !in s.enabledDays) return false
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val start = s.startHour * 60 + s.startMinute
        val end = s.endHour * 60 + s.endMinute
        val active = if (start <= end) now in start until end else now >= start || now < end
        if (!active && AutomationState.state.value.currentStep.isNotBlank()) AutomationState.finishCurrentThenStop = true
        return active
    }

    private suspend fun waitNode(candidates: List<String>, tries: Int): AccessibilityNodeInfo? {
        repeat(tries) { findNode(rootInActiveWindow, candidates)?.let { return it }; delay(800) }
        return null
    }
    private suspend fun waitEditableOrText(candidates: List<String>, tries: Int): AccessibilityNodeInfo? {
        repeat(tries) { findEditable(rootInActiveWindow)?.let { return it }; findNode(rootInActiveWindow, candidates)?.let { return it }; delay(800) }
        return null
    }
    private fun findNode(root: AccessibilityNodeInfo?, candidates: List<String>): AccessibilityNodeInfo? {
        if (root == null) return null
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst(); val hay = nodeText(n)
            if (candidates.any { hay.contains(it, true) } && (n.isClickable || n.parent?.isClickable == true || n.isEditable)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let(q::add)
        }
        return null
    }
    private fun findEditable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) { val n=q.removeFirst(); if (n.isEditable || n.className?.toString()?.contains("EditText") == true) return n; for(i in 0 until n.childCount) n.getChild(i)?.let(q::add) }
        return null
    }
    private fun clickableTextNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>(); val q = ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while (q.isNotEmpty()) { val n=q.removeFirst(); if ((n.isClickable || n.parent?.isClickable == true) && nodeText(n).isNotBlank()) out += n; for(i in 0 until n.childCount) n.getChild(i)?.let(q::add) }
        return out
    }
    private fun nodeText(n: AccessibilityNodeInfo): String = listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.viewIdResourceName).joinToString(" ")
    private fun containsAny(root: AccessibilityNodeInfo?, list: List<String>): Boolean {
        if (root == null) return false
        val all = buildString { clickableTextNodes(root).forEach { append(' ').append(nodeText(it)) } }
        return list.any { all.contains(it, true) }
    }
    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var p=n.parent; repeat(5) { if (p?.isClickable == true) return p!!.performAction(AccessibilityNodeInfo.ACTION_CLICK); p=p?.parent }
        return false
    }
    private fun setText(n: AccessibilityNodeInfo, text: String): Boolean = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) })
    private suspend fun update(step: String, keyword: String) { AutomationState.state.value = AutomationState.state.value.copy(status="작업 중", currentStep=step, currentKeyword=keyword); log("INFO",step,step) }
    private suspend fun log(level:String, step:String, message:String) { db.dao().insertLog(AppLogEntity(level=level, step=step, message=message, keyword=AutomationState.state.value.currentKeyword)) }
    private suspend fun saveHistory(id:String,title:String,blog:String,keyword:String,like:String,comment:String,overall:String,reason:String,started:Long,test:Boolean,used:String="") { db.dao().insertHistory(PostHistoryEntity(postUniqueId=id,postTitle=title,blogName=blog,keyword=keyword,likeResult=like,commentResult=comment,overallResult=overall,failureReason=reason,processingDuration=(System.currentTimeMillis()-started)/1000,testMode=test,usedComment=used)) }
    private suspend fun recordFailure(keyword:String, started:Long, reason:String) = saveHistory(sha256("$keyword|$started"),"","",keyword,"DISABLED","DISABLED","FAILED",reason,started,false)
    private suspend fun handleError(s:AppSettings, reason:String) { log("ERROR","ERROR",reason); if (s.errorAction=="STOP") stopWith(reason) else { AutomationState.pauseRequested=true; AutomationState.state.value=AutomationState.state.value.copy(status=reason,paused=true) } }
    private suspend fun stopWith(reason:String) { AutomationState.stopRequested=true; AutomationState.state.value=AutomationState.state.value.copy(running=false,status=reason); log("WARNING","STOP",reason) }
    private fun stopNow(reason:String) { AutomationState.stopRequested=true; AutomationState.state.value=AutomationState.state.value.copy(running=false,status=reason) }
    private fun sha256(s:String)=MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)}
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.KOREA).format(Date())
}
