package com.example.blogactivitymanager.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [KeywordEntity::class, CommentTemplateEntity::class, PostHistoryEntity::class, AppLogEntity::class, DailyStatsEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "blog_activity_manager.db")
                .fallbackToDestructiveMigration().build().also { instance = it }
        }
    }
}
