package com.example.blogactivitymanager

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.blogactivitymanager.data.*
import com.example.blogactivitymanager.service.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AppUi() } }
    }
}

@Composable
private fun AppUi() {
    val context = LocalContext.current
    val db = remember { AppDatabase.get(context) }
    val store = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()
    val runtime by AutomationState.state.collectAsStateWithLifecycle()
    val keywords by db.dao().observeKeywords().collectAsStateWithLifecycle(emptyList())
    val comments by db.dao().observeComments().collectAsStateWithLifecycle(emptyList())
    val history by db.dao().observeHistory().collectAsStateWithLifecycle(emptyList())
    val logs by db.dao().observeLogs().collectAsStateWithLifecycle(emptyList())
    val settings by store.settings.collectAsStateWithLifecycle(AppSettings())
    var tab by remember { mutableIntStateOf(0) }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    Scaffold(bottomBar = {
        NavigationBar {
            listOf("홈","키워드","댓글","기록","설정","로그").forEachIndexed { i, title ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(title) })
            }
        }
    }) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(runtime, settings,
                    onStart = { AutomationForegroundService.send(context, AutomationForegroundService.ACTION_START) },
                    onPause = { AutomationForegroundService.send(context, AutomationForegroundService.ACTION_PAUSE) },
                    onStop = { AutomationForegroundService.send(context, AutomationForegroundService.ACTION_STOP) },
                    onAccessibility = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
                1 -> KeywordScreen(keywords,
                    onAdd = { text, target -> scope.launch { db.dao().insertKeyword(KeywordEntity(keyword = text, dailyTarget = target, sortOrder = keywords.size)) } },
                    onToggle = { scope.launch { db.dao().updateKeyword(it.copy(enabled = !it.enabled, updatedAt = System.currentTimeMillis())) } },
                    onDelete = { scope.launch { db.dao().deleteKeyword(it) } })
                2 -> CommentScreen(comments,
                    onAdd = { scope.launch { db.dao().insertComment(CommentTemplateEntity(content = it, sortOrder = comments.size)) } },
                    onToggle = { scope.launch { db.dao().updateComment(it.copy(enabled = !it.enabled)) } },
                    onDelete = { scope.launch { db.dao().deleteComment(it) } })
                3 -> HistoryScreen(history)
                4 -> SettingsScreen(settings) { scope.launch { store.save(it) } }
                else -> LogScreen(logs)
            }
        }
    }
}

@Composable
private fun HomeScreen(s: RuntimeState, settings: AppSettings, onStart:()->Unit, onPause:()->Unit, onStop:()->Unit, onAccessibility:()->Unit) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Blog Activity Manager", style = MaterialTheme.typography.headlineSmall)
        Text("상태: ${s.status}")
        Text("현재 키워드: ${s.currentKeyword.ifBlank { "-" }}")
        Text("현재 게시글: ${s.currentPostTitle.ifBlank { "-" }}")
        Text("현재 단계: ${s.currentStep.ifBlank { "-" }}")
        Text("경과시간: ${formatSeconds(s.elapsedSeconds)} / 남은시간: ${formatSeconds(s.remainingSeconds)}")
        Text("오늘 처리: ${s.todayProcessed} / ${if (s.todayGoal > 0) s.todayGoal else settings.dailyPostLimit}")
        Text("좋아요 ${s.likeSuccess} · 댓글 ${s.commentSuccess} · 건너뜀 ${s.skipped} · 실패 ${s.errors}")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onStart, enabled = !s.running && (settings.likeEnabled || settings.commentEnabled)) { Text(if (settings.testMode) "테스트 시작" else "시작") }
            OutlinedButton(onClick = onPause, enabled = s.running) { Text(if (s.paused) "재개" else "일시정지") }
            OutlinedButton(onClick = onStop, enabled = s.running) { Text("중지") }
        }
        if (!settings.likeEnabled && !settings.commentEnabled) Text("좋아요 또는 댓글 기능을 하나 이상 활성화해주세요.")
        Button(onClick = onAccessibility) { Text("접근성 서비스 설정 열기") }
        Text("실제 사용 전 테스트 모드에서 검색·버튼 감지 결과를 확인하세요.")
    }
}

@Composable
private fun KeywordScreen(items: List<KeywordEntity>, onAdd:(String,Int)->Unit, onToggle:(KeywordEntity)->Unit, onDelete:(KeywordEntity)->Unit) {
    var text by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("5") }
    Column(Modifier.padding(16.dp)) {
        Text("키워드", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("검색 키워드") })
        OutlinedTextField(target, { target = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("하루 목표") })
        Button(onClick = { if (text.isNotBlank()) { onAdd(text.trim(), target.toIntOrNull()?.coerceAtLeast(1) ?: 5); text = "" } }, Modifier.padding(vertical = 8.dp)) { Text("추가") }
        LazyColumn {
            items(items, key = { it.id }) { k ->
                ListItem(
                    headlineContent = { Text(k.keyword) },
                    supportingContent = { Text("오늘 ${k.todayCount}/${k.dailyTarget}") },
                    leadingContent = { Checkbox(k.enabled, { onToggle(k) }) },
                    trailingContent = { TextButton(onClick = { onDelete(k) }) { Text("삭제") } }
                )
            }
        }
    }
}

@Composable
private fun CommentScreen(items: List<CommentTemplateEntity>, onAdd:(String)->Unit, onToggle:(CommentTemplateEntity)->Unit, onDelete:(CommentTemplateEntity)->Unit) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.padding(16.dp)) {
        Text("댓글 문구", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("댓글 내용") }, minLines = 3)
        Button(onClick = { if (text.isNotBlank()) { onAdd(text.trim()); text = "" } }, Modifier.padding(vertical = 8.dp)) { Text("저장") }
        LazyColumn {
            items(items, key = { it.id }) { c ->
                ListItem(
                    headlineContent = { Text(c.content) },
                    supportingContent = { Text("사용 ${c.useCount}회") },
                    leadingContent = { Checkbox(c.enabled, { onToggle(c) }) },
                    trailingContent = { TextButton(onClick = { onDelete(c) }) { Text("삭제") } }
                )
            }
        }
    }
}

@Composable
private fun HistoryScreen(items: List<PostHistoryEntity>) {
    LazyColumn(Modifier.padding(12.dp)) {
        items(items, key = { it.id }) { h ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("${fmt(h.processedAt)} · ${h.keyword}")
                    Text(h.postTitle.ifBlank { "게시글 제목 미확인" })
                    Text("좋아요 ${h.likeResult} · 댓글 ${h.commentResult}")
                    Text("결과 ${h.overallResult} · ${h.processingDuration}초")
                    if (h.failureReason.isNotBlank()) Text("사유: ${h.failureReason}")
                }
            }
        }
    }
}

@Composable
private fun LogScreen(items: List<AppLogEntity>) {
    LazyColumn(Modifier.padding(12.dp)) {
        items(items, key = { it.id }) { l -> Text("${fmt(l.timestamp)} [${l.level}] ${l.step} ${l.message}", Modifier.padding(6.dp)) }
    }
}

@Composable
private fun SettingsScreen(s: AppSettings, save:(AppSettings)->Unit) {
    var local by remember(s) { mutableStateOf(s) }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("설정", style = MaterialTheme.typography.headlineSmall) }
        item { CheckRow("좋아요 사용", local.likeEnabled) { local = local.copy(likeEnabled = it) } }
        item { CheckRow("댓글 사용", local.commentEnabled) { local = local.copy(commentEnabled = it) } }
        item { CheckRow("테스트 모드", local.testMode) { local = local.copy(testMode = it) } }
        item { CheckRow("운영시간 사용", local.scheduleEnabled) { local = local.copy(scheduleEnabled = it) } }
        item { CheckRow("휴식 사용", local.restEnabled) { local = local.copy(restEnabled = it) } }
        item { CheckRow("화면 켜짐 유지", local.keepScreenOn) { local = local.copy(keepScreenOn = it) } }
        item { NumberField("최소 작업시간(초)", local.minSeconds) { local = local.copy(minSeconds = it) } }
        item { NumberField("최대 작업시간(초)", local.maxSeconds) { local = local.copy(maxSeconds = it) } }
        item { NumberField("시작 시", local.startHour) { local = local.copy(startHour = it.coerceIn(0,23)) } }
        item { NumberField("시작 분", local.startMinute) { local = local.copy(startMinute = it.coerceIn(0,59)) } }
        item { NumberField("종료 시", local.endHour) { local = local.copy(endHour = it.coerceIn(0,23)) } }
        item { NumberField("종료 분", local.endMinute) { local = local.copy(endMinute = it.coerceIn(0,59)) } }
        item { NumberField("하루 최대 게시글", local.dailyPostLimit) { local = local.copy(dailyPostLimit = it) } }
        item { NumberField("하루 최대 좋아요", local.dailyLikeLimit) { local = local.copy(dailyLikeLimit = it) } }
        item { NumberField("하루 최대 댓글", local.dailyCommentLimit) { local = local.copy(dailyCommentLimit = it) } }
        item { NumberField("몇 개마다 휴식", local.restEvery) { local = local.copy(restEvery = it) } }
        item { NumberField("최소 휴식(분)", local.restMinMinutes) { local = local.copy(restMinMinutes = it) } }
        item { NumberField("최대 휴식(분)", local.restMaxMinutes) { local = local.copy(restMaxMinutes = it) } }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = local.commentMode == "SEQUENTIAL", onClick = { local = local.copy(commentMode = "SEQUENTIAL") }, label = { Text("댓글 순차") })
                FilterChip(selected = local.commentMode == "RANDOM", onClick = { local = local.copy(commentMode = "RANDOM") }, label = { Text("댓글 랜덤") })
            }
        }
        item { Button(onClick = { save(local) }, Modifier.fillMaxWidth()) { Text("설정 저장") } }
    }
}

@Composable private fun CheckRow(label:String, checked:Boolean, onChange:(Boolean)->Unit) { Row { Checkbox(checked, onChange); Text(label, Modifier.padding(top = 12.dp)) } }
@Composable private fun NumberField(label:String, value:Int, onChange:(Int)->Unit) { OutlinedTextField(value.toString(), { onChange(it.filter(Char::isDigit).toIntOrNull() ?: 0) }, Modifier.fillMaxWidth(), label = { Text(label) }) }
private fun fmt(t:Long) = SimpleDateFormat("MM-dd HH:mm:ss", Locale.KOREA).format(Date(t))
private fun formatSeconds(v:Int) = "%02d:%02d".format(v / 60, v % 60)
