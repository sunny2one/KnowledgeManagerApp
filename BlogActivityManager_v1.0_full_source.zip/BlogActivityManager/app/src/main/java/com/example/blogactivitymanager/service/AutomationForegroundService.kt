package com.example.blogactivitymanager.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.example.blogactivitymanager.MainActivity

class AutomationForegroundService : Service() {
    companion object {
        const val ACTION_START = "start"
        const val ACTION_PAUSE = "pause"
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "automation"
        private const val ID = 1001
        fun send(context: Context, action: String) {
            val i = Intent(context, AutomationForegroundService::class.java).setAction(action)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "작업 상태", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                AutomationState.stopRequested = false
                AutomationState.pauseRequested = false
                AutomationState.finishCurrentThenStop = false
                AutomationState.state.value = AutomationState.state.value.copy(running = true, paused = false, status = "시작됨")
                startForeground(ID, notification("Blog Activity Manager 실행 중"))
                packageManager.getLaunchIntentForPackage(NaverNodeTexts.NAVER_BLOG_PACKAGE)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(it)
                }
            }
            ACTION_PAUSE -> {
                AutomationState.pauseRequested = !AutomationState.pauseRequested
                AutomationState.state.value = AutomationState.state.value.copy(paused = AutomationState.pauseRequested, status = if (AutomationState.pauseRequested) "일시정지" else "재개")
            }
            ACTION_STOP -> {
                AutomationState.stopRequested = true
                AutomationState.state.value = AutomationState.state.value.copy(running = false, status = "사용자 중지")
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val pause = PendingIntent.getService(this, 1, Intent(this, javaClass).setAction(ACTION_PAUSE), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 2, Intent(this, javaClass).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Blog Activity Manager")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentIntent(open)
            .addAction(0, "일시정지/재개", pause)
            .addAction(0, "중지", stop)
            .setOngoing(true)
            .build()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
