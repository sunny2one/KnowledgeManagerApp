package com.example.blogactivitymanager.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "app_preferences")

enum class WorkState { STOPPED, RUNNING, PAUSED, TESTING }

class AppPreferences(private val context: Context) {
    private object Keys {
        val workState = stringPreferencesKey("work_state")
        val onboardingShown = booleanPreferencesKey("onboarding_shown")
    }

    val workState: Flow<WorkState> = context.dataStore.data.map { preferences ->
        runCatching { WorkState.valueOf(preferences[Keys.workState] ?: WorkState.STOPPED.name) }
            .getOrDefault(WorkState.STOPPED)
    }

    suspend fun setWorkState(state: WorkState) {
        context.dataStore.edit { it[Keys.workState] = state.name }
    }

    val onboardingShown: Flow<Boolean> = context.dataStore.data.map { it[Keys.onboardingShown] ?: false }

    suspend fun setOnboardingShown(shown: Boolean) {
        context.dataStore.edit { it[Keys.onboardingShown] = shown }
    }
}
