package com.example.blogactivitymanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.blogactivitymanager.data.db.AppDatabase
import com.example.blogactivitymanager.data.db.AppLogEntity
import com.example.blogactivitymanager.data.preferences.AppPreferences
import com.example.blogactivitymanager.data.preferences.WorkState
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = AppPreferences(application)
    private val dao = AppDatabase.getInstance(application).appDao()

    val workState: StateFlow<WorkState> = preferences.workState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), WorkState.STOPPED)
    val keywords = dao.observeKeywords().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val comments = dao.observeComments().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val history = dao.observeHistory().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val logs = dao.observeLogs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun changeState(state: WorkState) {
        viewModelScope.launch {
            preferences.setWorkState(state)
            dao.insertLog(
                AppLogEntity(
                    level = "INFO",
                    step = "1단계 상태 변경",
                    message = when (state) {
                        WorkState.RUNNING -> "기본 실행 상태로 변경했습니다. 자동 화면 조작은 아직 수행하지 않습니다."
                        WorkState.PAUSED -> "일시정지했습니다."
                        WorkState.TESTING -> "테스트 준비 상태로 변경했습니다."
                        WorkState.STOPPED -> "중지했습니다."
                    }
                )
            )
        }
    }
}
