package com.example.blogactivitymanager

import android.app.Application
import com.example.blogactivitymanager.data.db.AppDatabase

class BlogActivityManagerApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
}
