package com.example.blogactivitymanager.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow

class BlogAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // 1단계에서는 이벤트 수신 여부만 준비하고 화면 클릭은 수행하지 않습니다.
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        isConnected.value = false
        super.onDestroy()
    }

    companion object {
        val isConnected = MutableStateFlow(false)
    }
}
