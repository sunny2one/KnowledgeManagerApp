package com.example.blogactivitymanager.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "keywords")
data class KeywordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val keyword: String,
    val enabled: Boolean = true,
    val dailyTarget: Int = 5,
    val sortOrder: Int = 0,
    val todayCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comment_templates")
data class CommentTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val enabled: Boolean = true,
    val useCount: Int = 0,
    val lastUsedAt: Long? = null,
    val sortOrder: Int = 0
)

@Entity(tableName = "post_history")
data class PostHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val postUniqueId: String,
    val postTitle: String = "",
    val blogName: String = "",
    val postUrl: String = "",
    val keyword: String = "",
    val processedAt: Long = System.currentTimeMillis(),
    val likeResult: String = "DISABLED",
    val commentResult: String = "DISABLED",
    val overallResult: String = "SKIPPED",
    val usedComment: String = "",
    val failureReason: String = "",
    val processingDuration: Long = 0,
    val testMode: Boolean = false
)

@Entity(tableName = "app_logs")
data class AppLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val level: String = "INFO",
    val step: String = "",
    val message: String,
    val keyword: String = "",
    val postUniqueId: String = ""
)

@Entity(tableName = "daily_stats")
data class DailyStatsEntity(
    @PrimaryKey val date: String,
    val processedCount: Int = 0,
    val likeSuccessCount: Int = 0,
    val commentSuccessCount: Int = 0,
    val skipCount: Int = 0,
    val failureCount: Int = 0
)
