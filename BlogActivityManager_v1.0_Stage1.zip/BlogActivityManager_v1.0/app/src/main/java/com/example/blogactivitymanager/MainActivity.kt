package com.example.blogactivitymanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.blogactivitymanager.data.preferences.WorkState
import com.example.blogactivitymanager.service.ActivityForegroundService
import com.example.blogactivitymanager.service.BlogAccessibilityService
import com.example.blogactivitymanager.ui.theme.BlogActivityManagerTheme
import com.example.blogactivitymanager.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BlogActivityManagerTheme {
                BlogActivityApp(viewModel)
            }
        }
    }
}

enum class AppTab(val title: String) {
    HOME("홈"), KEYWORDS("키워드"), COMMENTS("댓글"), HISTORY("기록"), SETTINGS("설정"), LOGS("로그")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BlogActivityApp(viewModel: MainViewModel) {
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.HOME) }
    val workState by viewModel.workState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Blog Activity Manager", fontWeight = FontWeight.Bold)
                        Text("1단계 · 기본 프로젝트", style = MaterialTheme.typography.labelMedium)
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                AppTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(tab.icon(), contentDescription = tab.title) },
                        label = { Text(tab.title) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (selectedTab) {
                AppTab.HOME -> HomeScreen(workState, viewModel::changeState)
                AppTab.KEYWORDS -> PlaceholderScreen("키워드", "2단계에서 키워드 추가·수정·순서 변경 기능을 연결합니다.")
                AppTab.COMMENTS -> PlaceholderScreen("댓글", "2단계에서 댓글 문구 저장과 순차·랜덤 선택을 연결합니다.")
                AppTab.HISTORY -> HistoryScreen(viewModel)
                AppTab.SETTINGS -> SettingsScreen()
                AppTab.LOGS -> LogsScreen(viewModel)
            }
        }
    }
}

private fun AppTab.icon() = when (this) {
    AppTab.HOME -> Icons.Outlined.Home
    AppTab.KEYWORDS -> Icons.Outlined.Search
    AppTab.COMMENTS -> Icons.Outlined.ChatBubbleOutline
    AppTab.HISTORY -> Icons.Outlined.History
    AppTab.SETTINGS -> Icons.Outlined.Settings
    AppTab.LOGS -> Icons.Outlined.ListAlt
}

@Composable
private fun HomeScreen(state: WorkState, onStateChange: (WorkState) -> Unit) {
    val context = LocalContext.current
    val accessibilityConnected by BlogAccessibilityService.isConnected.collectAsStateWithLifecycle()
    val notificationGranted = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("현재 상태", style = MaterialTheme.typography.titleMedium)
                    Text(state.displayName(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    HorizontalDivider()
                    StatusRow("현재 키워드", "준비되지 않음")
                    StatusRow("현재 게시글 제목", "-")
                    StatusRow("현재 블로그명", "-")
                    StatusRow("현재 단계", "1단계 기본 동작 확인")
                    StatusRow("오늘 처리", "0 / 0")
                    StatusRow("좋아요 / 댓글 / 건너뜀", "0 / 0 / 0")
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        onStateChange(WorkState.RUNNING)
                        ActivityForegroundService.start(context)
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("시작") }
                OutlinedButton(
                    onClick = {
                        onStateChange(WorkState.PAUSED)
                        ActivityForegroundService.start(context, ActivityForegroundService.ACTION_PAUSE)
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("일시정지") }
                OutlinedButton(
                    onClick = {
                        onStateChange(WorkState.STOPPED)
                        ActivityForegroundService.start(context, ActivityForegroundService.ACTION_STOP)
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("중지") }
            }
        }
        item {
            Button(
                onClick = {
                    onStateChange(WorkState.TESTING)
                    ActivityForegroundService.start(context, ActivityForegroundService.ACTION_TEST)
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("테스트 시작") }
        }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("권한 상태", style = MaterialTheme.typography.titleMedium)
                    PermissionRow("접근성 서비스", if (accessibilityConnected) "연결됨" else "연결 필요")
                    PermissionRow("알림 권한", if (notificationGranted) "허용됨" else "허용 필요")
                    PermissionRow("배터리 최적화", "설정 확인 필요")
                    OutlinedButton(
                        onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("접근성 설정 열기") }
                    if (!notificationGranted && Build.VERSION.SDK_INT >= 33) {
                        OutlinedButton(
                            onClick = { notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("알림 권한 허용") }
                    }
                }
            }
        }
        item {
            Text(
                "1단계의 시작 버튼은 상태 저장과 실행 알림만 확인합니다. 네이버 앱 검색, 좋아요, 댓글 입력은 수행하지 않습니다.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PermissionRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Security, null)
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun PlaceholderScreen(title: String, description: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        ElevatedCard {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text(description)
            }
        }
    }
}

@Composable
private fun HistoryScreen(viewModel: MainViewModel) {
    val history by viewModel.history.collectAsStateWithLifecycle()
    if (history.isEmpty()) PlaceholderScreen("기록", "아직 저장된 작업 기록이 없습니다.")
    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        items(history, key = { it.id }) { item ->
            ListItem(headlineContent = { Text(item.postTitle.ifBlank { item.postUniqueId }) }, supportingContent = { Text(item.overallResult) })
            HorizontalDivider()
        }
    }
}

@Composable
private fun LogsScreen(viewModel: MainViewModel) {
    val logs by viewModel.logs.collectAsStateWithLifecycle()
    if (logs.isEmpty()) PlaceholderScreen("로그", "시작·일시정지·중지 버튼을 누르면 기본 로그가 저장됩니다.")
    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        items(logs, key = { it.id }) { log ->
            ListItem(
                headlineContent = { Text("${log.level} · ${log.step}") },
                supportingContent = { Text(log.message) }
            )
            HorizontalDivider()
        }
    }
}

@Composable
private fun SettingsScreen() {
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("설정", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            ElevatedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("1단계 권한 및 서비스")
                    OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                        Text("접근성 서비스 설정")
                    }
                    OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) {
                        Text("배터리 최적화 설정")
                    }
                    Text("좋아요·댓글·운영시간·휴식 설정은 2단계에서 활성화됩니다.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

private fun WorkState.displayName() = when (this) {
    WorkState.STOPPED -> "중지됨"
    WorkState.RUNNING -> "실행 중"
    WorkState.PAUSED -> "일시정지"
    WorkState.TESTING -> "테스트 준비"
}
