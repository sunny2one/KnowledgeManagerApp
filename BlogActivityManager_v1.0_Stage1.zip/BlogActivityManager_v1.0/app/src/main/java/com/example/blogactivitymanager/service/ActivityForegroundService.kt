package com.example.blogactivitymanager.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.blogactivitymanager.MainActivity
import com.example.blogactivitymanager.R

class ActivityForegroundService : Service() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> currentStatus = "일시정지"
            ACTION_TEST -> currentStatus = "테스트 준비 중"
            else -> currentStatus = "실행 중"
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification() = NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(R.drawable.ic_launcher_foreground)
        .setContentTitle("Blog Activity Manager 실행 중")
        .setContentText("현재 상태: $currentStatus")
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        .addAction(R.drawable.ic_pause, "일시정지", servicePendingIntent(ACTION_PAUSE, 1))
        .addAction(R.drawable.ic_stop, "중지", servicePendingIntent(ACTION_STOP, 2))
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .build()

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this,
            requestCode,
            Intent(this, ActivityForegroundService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "작업 상태",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Blog Activity Manager 실행 상태 알림" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val ACTION_START = "com.example.blogactivitymanager.action.START"
        const val ACTION_PAUSE = "com.example.blogactivitymanager.action.PAUSE"
        const val ACTION_STOP = "com.example.blogactivitymanager.action.STOP"
        const val ACTION_TEST = "com.example.blogactivitymanager.action.TEST"
        private const val CHANNEL_ID = "blog_activity_status"
        private const val NOTIFICATION_ID = 1001
        private var currentStatus = "실행 중"

        fun start(context: Context, action: String = ACTION_START) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, ActivityForegroundService::class.java).setAction(action)
            )
        }
    }
}
