package com.example.blogactivitymanager.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM keywords ORDER BY sortOrder, id")
    fun observeKeywords(): Flow<List<KeywordEntity>>

    @Query("SELECT * FROM comment_templates ORDER BY sortOrder, id")
    fun observeComments(): Flow<List<CommentTemplateEntity>>

    @Query("SELECT * FROM post_history ORDER BY processedAt DESC LIMIT 200")
    fun observeHistory(): Flow<List<PostHistoryEntity>>

    @Query("SELECT * FROM app_logs ORDER BY timestamp DESC LIMIT 500")
    fun observeLogs(): Flow<List<AppLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AppLogEntity)
}
