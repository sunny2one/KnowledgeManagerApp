package com.example.blogactivitymanager.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        KeywordEntity::class,
        CommentTemplateEntity::class,
        PostHistoryEntity::class,
        AppLogEntity::class,
        DailyStatsEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "blog_activity_manager.db"
                ).fallbackToDestructiveMigration(false).build().also { INSTANCE = it }
            }
    }
}
