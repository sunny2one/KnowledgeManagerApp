# Room entities and database metadata
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }

# Accessibility service class is also declared in AndroidManifest.xml.
-keep class com.example.blogactivitymanager.service.BlogAccessibilityService { *; }
-keep class com.example.blogactivitymanager.service.ActivityForegroundService { *; }
