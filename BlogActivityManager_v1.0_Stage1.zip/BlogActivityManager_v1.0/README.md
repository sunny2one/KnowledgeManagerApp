# Blog Activity Manager v1.0 — 1단계

Android 접근성 서비스 기반 관리 앱의 **빌드 가능한 기본 프로젝트**입니다.

> 1단계에서는 네이버 앱 화면을 자동으로 누르지 않습니다. 앱 화면, 상태 저장, Room, DataStore, 접근성 서비스 등록, Foreground Service 알림과 GitHub Actions 빌드를 먼저 검증합니다.

## 프로젝트 정보

- 앱 이름: Blog Activity Manager
- 패키지명: `com.example.blogactivitymanager`
- versionCode: `1`
- versionName: `1.0`
- 최소 Android: Android 9 / API 28
- compileSdk / targetSdk: API 36
- 언어: Kotlin
- UI: Jetpack Compose
- DB: Room SQLite
- 설정 저장: DataStore Preferences
- 백그라운드 상태: Foreground Service
- 화면 이벤트 준비: AccessibilityService

## 1단계 포함 기능

- 홈, 키워드, 댓글, 기록, 설정, 로그의 6개 하단 탭
- 시작, 일시정지, 중지, 테스트 시작 버튼
- DataStore에 작업 상태 저장
- Room DB와 5개 테이블 기본 생성
- 접근성 서비스 등록 및 연결 상태 표시
- Android 13 이상 알림 권한 요청
- Foreground Service 실행 알림
- 알림의 일시정지·중지 동작
- 시작·일시정지·중지 로그 저장
- GitHub Actions APK 빌드
- 독립 패키지명과 앱 아이콘

## Android Studio 빌드

1. Android Studio에서 이 폴더를 엽니다.
2. Gradle Sync가 끝날 때까지 기다립니다.
3. Android SDK Platform 36이 없다면 SDK Manager에서 설치합니다.
4. `Build > Build APK(s)`를 실행합니다.
5. 결과 APK는 `app/build/outputs/apk/debug/app-debug.apk`에 생성됩니다.

명령줄 빌드(Gradle 8.13이 설치된 경우):

```bash
gradle wrapper --gradle-version 8.13
./gradlew :app:assembleDebug
```

GitHub Actions에서는 Gradle 8.13을 설치한 뒤 Wrapper를 자동 생성합니다.

## GitHub Actions 빌드

1. 이 폴더의 모든 파일을 GitHub 저장소 `main` 브랜치에 올립니다.
2. GitHub 저장소의 `Actions` 탭을 엽니다.
3. `Build Blog Activity Manager APK`를 선택합니다.
4. `Run workflow`를 누릅니다.
5. 빌드가 끝나면 실행 결과 아래 `Artifacts`에서 `BlogActivityManager_v1.0`을 받습니다.
6. 압축을 풀면 `BlogActivityManager_v1.0.apk`가 있습니다.

## APK 설치

1. APK를 휴대전화로 옮깁니다.
2. 파일을 누르고 출처를 알 수 없는 앱 설치를 허용합니다.
3. `Blog Activity Manager`를 설치합니다.
4. 패키지명이 독립적이므로 기존의 다른 APK를 덮어쓰지 않습니다.

## 접근성 서비스 설정

1. 앱 홈 화면에서 `접근성 설정 열기`를 누릅니다.
2. 설치된 앱 또는 다운로드한 앱 목록에서 `Blog Activity Manager 접근성 서비스`를 선택합니다.
3. 서비스를 허용합니다.
4. 앱으로 돌아오면 홈 화면에 `접근성 서비스: 연결됨`이 표시됩니다.

1단계의 접근성 서비스는 화면 이벤트를 받을 준비만 하며 클릭하지 않습니다.

## 배터리 최적화 설정

1. 설정 탭에서 `배터리 최적화 설정`을 누릅니다.
2. Blog Activity Manager를 찾아 최적화 제외 대상으로 설정합니다.
3. 제조사별 메뉴 이름은 `제한 없음`, `최적화하지 않음`, `백그라운드 허용` 등으로 다를 수 있습니다.

## 테스트 모드

홈 화면의 `테스트 시작`은 1단계에서 상태와 알림만 테스트합니다.

- 실제 좋아요 클릭 없음
- 실제 댓글 입력 없음
- 네이버 앱 자동 실행 없음
- Room 로그에 테스트 준비 상태 저장

실제 화면 노드 분석 테스트는 3단계에서 추가됩니다.

## 키워드와 댓글 등록

1단계에서는 탭과 DB 테이블만 준비되어 있습니다. 추가·수정·삭제 화면은 2단계에서 연결합니다.

## 운영시간 설정

운영시간, 요일, 휴식, 하루 최대 수는 2단계에서 DataStore 설정 화면으로 추가됩니다.

## 로그 확인

1. 홈에서 시작, 일시정지, 테스트 시작 또는 중지를 누릅니다.
2. 하단의 `로그` 탭을 누릅니다.
3. 상태 변경 로그가 최신순으로 표시됩니다.

## 주요 파일

- `MainActivity.kt`: Compose 화면과 6개 탭
- `BlogAccessibilityService.kt`: 접근성 서비스 기본 등록
- `ActivityForegroundService.kt`: 실행 상태 알림
- `Entities.kt`: Room 테이블 5개
- `AppDatabase.kt`, `AppDao.kt`: Room DB
- `AppPreferences.kt`: DataStore 상태 저장
- `MainViewModel.kt`: MVVM 상태 연결
- `.github/workflows/build-apk.yml`: GitHub Actions APK 빌드

## 다음 단계

2단계에서 키워드·댓글 문구 CRUD, 좋아요/댓글 ON·OFF, 작업시간, 운영시간, 최대 작업 수, 휴식 등 설정 화면과 영구 저장을 완성합니다.
