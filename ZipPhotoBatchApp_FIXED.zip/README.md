# ZIP 사진 일괄 저장 APK

## 동작
1. 앱에서 `ZIP 파일 선택하고 바로 처리`를 누릅니다.
2. 다운로드한 ZIP 파일을 선택합니다.
3. ZIP 안의 JPG/JPEG/PNG/WEBP/HEIC/HEIF 사진을 읽습니다.
4. 원본 해상도를 유지한 채 JPEG 품질 95%로 새로 저장합니다.
5. EXIF 등 기존 메타데이터는 복사하지 않습니다.
6. 결과는 갤러리의 `Pictures/BlogReady/날짜_시간` 폴더에 생성됩니다.

원본 ZIP과 원본 사진은 삭제하지 않습니다.

## GitHub에서 APK 만들기
1. GitHub에서 새 저장소를 만듭니다.
2. 이 프로젝트의 모든 파일을 저장소에 업로드합니다.
3. 상단 `Actions` 메뉴로 들어갑니다.
4. `Build Android APK`를 선택하고 `Run workflow`를 누릅니다.
5. 작업 완료 후 `Artifacts`의 `ZIP-Photo-Batch-APK`를 내려받습니다.
6. 압축을 풀면 `app-debug.apk`가 있습니다.

## 기본 설정
- 앱 이름: ZIP 사진 일괄 저장
- 패키지명: com.rose.zipphotobatch
- 최소 Android: Android 8.0
- 출력 품질: JPEG 95%
- 출력 크기: 원본 크기 유지
- 저장 위치: Pictures/BlogReady

## 매우 중요
GitHub 저장소를 열었을 때 첫 화면에 바로 `app`, `.github`, `build.gradle`, `settings.gradle`이 보여야 합니다.
`ZipPhotoBatchApp` 폴더 안에 다시 프로젝트가 들어가 있으면 빌드 경로가 틀어질 수 있습니다.
